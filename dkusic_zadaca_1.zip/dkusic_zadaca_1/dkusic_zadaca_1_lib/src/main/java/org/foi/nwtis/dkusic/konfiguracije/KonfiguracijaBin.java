package org.foi.nwtis.dkusic.konfiguracije;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.foi.nwtis.KonfiguracijaApstraktna;
import org.foi.nwtis.NeispravnaKonfiguracija;

/**
 * Klasa KonfiguracijaTxt za rad s postavkama konfiguracije u .bin formatu
 *
 * @author Davor Kušić
 */
public class KonfiguracijaBin extends KonfiguracijaApstraktna {
	
	  /** Konstanta TIP. */
	public static final String TIP = "bin";

	  /**
	   * Konstruktor klase, instancira klasu KonfiguracijaBin
	   *
	   * @param nazivDatoteke naziv datoteke
	   * @throws NeispravnaKonfiguracija ako tip nije podržan ili se javi problem kod spremanja datoteke
	   *         konfiguracije
	   */
	public KonfiguracijaBin(String nazivDatoteke) throws NeispravnaKonfiguracija {
		super(nazivDatoteke);
	}

	  /**
	   * Sprema konfiguraciju pod danim nazivom datoteke.
	   *
	   * @param datoteka naziv datoteke konfiguracije
	   * @throws NeispravnaKonfiguracija ako tip nije podržan ili se javi problem kod spremanja datoteke
	   *         konfiguracije
	   */
	@Override
	public void spremiKonfiguraciju(String datoteka) throws NeispravnaKonfiguracija {
		try {
			FileOutputStream f = new FileOutputStream(datoteka);
			ObjectOutputStream ous = new ObjectOutputStream(f);
			ous.writeObject(postavke);
			ous.close();
		} catch (IOException e) {
			throw new NeispravnaKonfiguracija();
		}
	}

	/**
	 * Učitaj konfiguraciju.
	 *
	 * @throws NeispravnaKonfiguracija the neispravna konfiguracija
	 */
	@Override
	public void ucitajKonfiguraciju() throws NeispravnaKonfiguracija {
		try {
			FileInputStream f = new FileInputStream(nazivDatoteke + TIP);
			ObjectInputStream ois = new ObjectInputStream(f);
			ois.readObject();
			ois.close();
		} catch (IOException | ClassNotFoundException e) {
			throw new NeispravnaKonfiguracija();
		}
	}
}