/**
 * 
 */
package org.foi.nwtis.dkusic.konfiguracije;

import org.foi.nwtis.KonfiguracijaApstraktna;
import org.foi.nwtis.NeispravnaKonfiguracija;

/**
 * Klasa KonfiguracijaTxt za rad s postavkama konfiguracije u .yaml formatu
 *
 * @author Davor Kušić
 */
public class KonfiguracijaYaml extends KonfiguracijaApstraktna {

  /** Konstanta TIP. */
  public static final String TIP = "yaml";

  /**
   * Instancira klasu KonfiguracijaYaml
   * 
   * @param nazivDatoteke naziv datoteke konfiguracije
   */
  public KonfiguracijaYaml(String nazivDatoteke) {
    super(nazivDatoteke);
  }
  /**
   * Sprema konfiguraciju pod danim nazivom datoteke.
   *
   * @param datoteka naziv datoteke konfiguracije
   * @throws NeispravnaKonfiguracija ako tip nije podržan ili se javi problem kod spremanja datoteke
   *         konfiguracije
   */
  @Override
  public void spremiKonfiguraciju(String datoteka) throws NeispravnaKonfiguracija {

  }
	/**
	 * Učitaj konfiguraciju.
	 *
	 * @throws NeispravnaKonfiguracija baca grešku kod učitavanja neispravne konfiguracije
	 */
  @Override
  public void ucitajKonfiguraciju() throws NeispravnaKonfiguracija {

  }

}
