/**
 * 
 */
package org.foi.nwtis.dkusic.konfiguracije;

import org.foi.nwtis.KonfiguracijaApstraktna;
import org.foi.nwtis.NeispravnaKonfiguracija;

/**
 * Klasa KonfiguracijaTxt za rad s postavkama konfiguracije u .json formatu
 *
 * @author Davor Kušić
 */
public class KonfiguracijaJson extends KonfiguracijaApstraktna {
	  /** Konstanta TIP označava tip konfiguracije. */
  public static final String TIP = "json";

  /**
   * Instancira novu konfiguracije za tip JSON.
   *
   * @param nazivDatoteke naziv datoteke konfiguracije
   */
  public KonfiguracijaJson(String nazivDatoteke) {
    super(nazivDatoteke);
  }
  /**
   * Sprema konfiguraciju pod danim nazivom datoteke.
   *
   * @param datoteka naziv datoteke konfiguracije
   * @throws NeispravnaKonfiguracija ako tip nije podržan ili se javi problem kod spremanja datoteke
   *         konfiguracije
   */
  @Override
  public void spremiKonfiguraciju(String datoteka) throws NeispravnaKonfiguracija {

  }
	/**
	 * Učitaj konfiguraciju.
	 *
	 * @throws NeispravnaKonfiguracija baca grešku ako je neispravna konfiguracija pri učitavanju
	 */
  @Override
  public void ucitajKonfiguraciju() throws NeispravnaKonfiguracija {

  }

}
