package org.foi.nwtis.dkusic.zadaca_1.podaci;

/**
 * zapis tipa Uređaj, služi za pohranu informacija o uređajima
 */
public record Uredaj(String naziv, String id, String idLokacija, UredajVrsta vrsta) {

}
