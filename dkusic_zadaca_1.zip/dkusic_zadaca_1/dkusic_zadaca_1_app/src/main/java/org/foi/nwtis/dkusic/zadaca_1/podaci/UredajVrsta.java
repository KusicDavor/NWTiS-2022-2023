package org.foi.nwtis.dkusic.zadaca_1.podaci;

/**
 * enumeracija za vrste uređaja
 */
public enum UredajVrsta {

	/** The Senzor temperatura. */
	SenzorTemperatura(1),
	/** The Senzor vlaga. */
	SenzorVlaga(2),
	/** The Senzor tlak. */
	SenzorTlak(3),
	/** The Senzor svjetlo. */
	SenzorSvjetlo(4),
	/** The Senzor kontakt. */
	SenzorKontakt(5),
	/** The Senzor temperatura vlaga. */
	SenzorTemperaturaVlaga(50),

	/** The Senzor temperatura tlak. */
	SenzorTemperaturaTlak(51),
	/** The Senzor temperatura vlaga tlak. */
	SenzorTemperaturaVlagaTlak(52),
	/** The Aktuator ventilator. */
	AktuatorVentilator(100),
	/** The Aktuator grijanje. */
	AktuatorGrijanje(101),

	/** The Aktuator rasvjeta. */
	AktuatorRasvjeta(102),
	/** The Aktuator vrata. */
	AktuatorVrata(103);

	/** The broj. */
	private int broj;

	/**
	 * Instancira novi UredajVrsta po broju koji je oznaka tipa uređaja.
	 *
	 * @param broj oznaka tipa uređaja
	 */
	private UredajVrsta(int broj) {
		this.broj = broj;
	}

	/**
	 * Konstruktor nove vrste uređaja.
	 *
	 * @param broj oznaka vrste uređaja
	 * @return novu vrstu uređaja klase UredajVrsta koji se može pridružiti uređaju
	 */
	public static UredajVrsta odBroja(int broj) {
		for (UredajVrsta uv : UredajVrsta.values()) {
			if (uv.broj == broj) {
				return uv;
			}
		}

		throw new IllegalArgumentException("Ne postoji vrsta za vrijednost: " + broj + ".");
	}
}