package org.foi.nwtis.dkusic.zadaca_1.podaci;

/**
 * zapis MeteoSimulacija služi za kreiranje objekta koji predstavlja jedno mjerenje uređaja sa svojim podacima
 */
public record MeteoSimulacija(String id, String vrijeme, float temperatura, float vlaga, float tlak) {
}
