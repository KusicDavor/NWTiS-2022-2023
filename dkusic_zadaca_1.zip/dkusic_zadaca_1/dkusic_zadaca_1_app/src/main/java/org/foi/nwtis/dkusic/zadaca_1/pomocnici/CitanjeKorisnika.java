package org.foi.nwtis.dkusic.zadaca_1.pomocnici;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.dkusic.zadaca_1.podaci.Korisnik;

/**
 * Intancira klasu CitanjeKorisnika koja služi za učitavanje korisnika i
 * spremanje na glavni poslužitelj.
 */
public class CitanjeKorisnika {

	/**
	 * Ucitaj datoteku.
	 *
	 * @param nazivDatoteke naziv datoteke koja sadrži podatke o korisnicima
	 * @return map koji sadrži sve korisnike
	 * @throws IOException Ako je čitanje bilo neuspješno.
	 */
	public Map<String, Korisnik> ucitajDatoteku(String nazivDatoteke) throws IOException {
		var putanja = Path.of(nazivDatoteke);
		if (!Files.exists(putanja) || Files.isDirectory(putanja) || !Files.isReadable(putanja)) {
			throw new IOException("Datoteka '" + nazivDatoteke + "' nije datoteka ili nije moguće čitati.");
		}
		var korisnici = new HashMap<String, Korisnik>();
		var citac = Files.newBufferedReader(putanja, Charset.forName("UTF-8"));

		while (true) {
			var redak = citac.readLine();
			if (redak == null) {
				break;
			}
			var odsjek = redak.split(";");
			if (odsjek.length != 5) {
				Logger.getGlobal().log(Level.WARNING, "ERROR 29: Greška u datoteci s podacima lokacija.");
			} else {
				boolean administrator = odsjek[4].compareTo("1") == 0 ? true : false;
				var korisnik = new Korisnik(odsjek[0], odsjek[1], odsjek[2], odsjek[3], administrator);
				korisnici.put(odsjek[2], korisnik);

			}
		}
		return korisnici;
	}
}
