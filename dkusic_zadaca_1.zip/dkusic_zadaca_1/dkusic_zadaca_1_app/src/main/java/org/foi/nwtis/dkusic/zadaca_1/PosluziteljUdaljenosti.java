package org.foi.nwtis.dkusic.zadaca_1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.Serial;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.Konfiguracija;
import org.foi.nwtis.KonfiguracijaApstraktna;
import org.foi.nwtis.NeispravnaKonfiguracija;

/**
 * Klasa služi za provjeru argumenata, učitavanje postavki i pokretanje klase
 * PosluziteljUdaljenosti.
 *
 * @author Davor Kušić
 */
public class PosluziteljUdaljenosti {

	/** Konfiguracijska datoteka */
	protected static Konfiguracija konfig;

	/**
	 * Atribut ispis označava potrebu za ispisom tekućeg podatka pri radu programa
	 */
	private static int ispis;

	/** maksimalni broj zahtjeva koje server prihvaća istovremeno */
	private static int brojCekaca;

	/** broj posljenjih zapisa koji se pohranjuju i serijaliziraju */
	private int brojZadnjihSpremljenih;

	/** ime datotete serijalizacije. */
	private static String imeDatoteteSerijalizacije;

	@Serial
	/** lista svih zahtjeva prema PosluziteljuUdaljenosti. */
	private static List<String[]> listaZahtjeva;

	/**
	 * Kreira novi objek klase PosluziteljUdaljenosti
	 *
	 * @param konfig prima konfiguracijsku datoteku
	 * @throws NeispravnaKonfiguracija baca pogrešku ako je učitavanje podataka iz
	 *                                 konfiguracije bilo neuspješno
	 */
	public PosluziteljUdaljenosti(Konfiguracija konfig) throws NeispravnaKonfiguracija {
		super();
		this.konfig = konfig;
		this.ispis = Integer.parseInt(this.konfig.dajPostavku("ispis"));
		this.brojCekaca = Integer.parseInt(this.konfig.dajPostavku("brojCekaca"));
		this.brojZadnjihSpremljenih = Integer.parseInt(this.konfig.dajPostavku("brojZadnjihSpremljenih"));
		PosluziteljUdaljenosti.imeDatoteteSerijalizacije = PosluziteljUdaljenosti.konfig
				.dajPostavku("datotekaSerijalizacija");
		listaZahtjeva = new ArrayList<>(brojZadnjihSpremljenih);
		if (!provjeraDatoteke(PosluziteljUdaljenosti.konfig.dajPostavku("datotekaSerijalizacija"))) {
			throw new NeispravnaKonfiguracija("ERROR 19: Pogreška kod datoteke postavki.");
		} else {

		}
	}

	/**
	 * Glavna metoda poslužitelja udaljenosti
	 *
	 * @param args ulazni argument je ime konfiguracijske datoteke
	 * @throws IOException baca grešku ako dođe do pogreške u radu sa socketm
	 */
	public static void main(String[] args) throws IOException {
		if (!provjeriArgumente(args)) {
			Logger.getLogger(PosluziteljUdaljenosti.class.getName()).log(Level.WARNING, "Nije upisan naziv datoteke");
			return;
		}
		try {
			var konfiguracija = ucitajPostavke(args[0]);
			var PosluziteljUdaljenosti = new PosluziteljUdaljenosti(konfiguracija);
			deserijalizacija(imeDatoteteSerijalizacije);
			otvoriMreznaVrata(PosluziteljUdaljenosti);
		} catch (NeispravnaKonfiguracija e) {
			Logger.getLogger(PosluziteljUdaljenosti.class.getName()).log(Level.WARNING,
					"ERROR 19: Pogreška kod datoteke postavki. " + e.getMessage());
		} catch (InterruptedException e) {
			Logger.getGlobal().log(Level.WARNING,
					"ERROR 19: Došlo je do prekida u radu poslužitelja. " + e.getMessage());
		}
	}

	/**
	 * Provjerava broj unesenih argumenata-
	 *
	 * @param args Argumenti
	 * @return true, ako postoji jedan argument, inače false
	 */
	static boolean provjeriArgumente(String[] args) {
		return args.length == 1 ? true : false;
	}

	/**
	 * Učitaj postavke iz datoteke
	 *
	 * @param nazivDatoteke Naziv datoteke
	 * @return objekt Konfiguracija
	 * @throws NeispravnaKonfiguracija ako nije ispravna konfiguracija
	 */
	static Konfiguracija ucitajPostavke(String nazivDatoteke) throws NeispravnaKonfiguracija {
		return KonfiguracijaApstraktna.preuzmiKonfiguraciju(nazivDatoteke);
	}

	/**
	 * Provjera postojanja datoteke serijalizacije
	 *
	 * @param datoteka naziv datoteke serijalizacije
	 * @return true, ako datoteka postoji
	 * @throws NeispravnaKonfiguracija baca grešku ako dođe do pogreške u
	 *                                 komunikacaiji
	 */
	public static boolean provjeraDatoteke(String datoteka) throws NeispravnaKonfiguracija {
		File file = new File(datoteka);
		if (!file.exists()) {
			throw new NeispravnaKonfiguracija("ERROR 19: Nema datoteke s podacima.");
		}
		return true;
	}

	/**
	 * Otvara mrežna vrata.
	 *
	 * @param posluziteljUdaljenosti instancu glavne klase, otvara komunikaciju sa
	 *                               klijentima
	 * @throws InterruptedException baca pogrešku ako je program prekinu
	 * @throws IOException          Signalizira da je došlo do pogreške u
	 *                              komunikaciji s klijentima
	 */
	public static void otvoriMreznaVrata(PosluziteljUdaljenosti posluziteljUdaljenosti)
			throws InterruptedException, IOException {
		ServerSocket server = null;
		Socket klijent = null;
		BufferedReader citac = null;
		BufferedWriter pisac = null;
		try {
			while (true) {
				server = new ServerSocket(Integer.parseInt(posluziteljUdaljenosti.konfig.dajPostavku("mreznaVrata")),
						brojCekaca);
				klijent = server.accept();

				citac = new BufferedReader(new InputStreamReader(klijent.getInputStream()));
				pisac = new BufferedWriter(new OutputStreamWriter(klijent.getOutputStream(), Charset.forName("UTF-8")));

				String redak;
				while ((redak = citac.readLine()) != null) {
					if (ispis == 1) {
						Logger.getGlobal().log(Level.INFO, redak);
					}
					String odgovor = preusmjeri(redak);
					pisac.write(odgovor);
					pisac.flush();
				}
				citac.close();
				pisac.close();
				klijent.close();
				server.close();
			}
		} catch (IOException e) {
			Logger.getGlobal().log(Level.WARNING, "EERROR 19: Pogreška pri radu sa socketom. " + e.getMessage(),
					StandardCharsets.UTF_8);
		}
	}

	/**
	 * razlikuje naredbu za izračun udaljenosti između lokacija od naredbe za
	 * spremanje od naredbe za serijalizaciju
	 *
	 * @param komanda the komanda
	 * @return predmetni dio poruke
	 */
	private static String preusmjeri(String komanda) {
		String odgovor = "ERROR 19: Nema podataka za serijalizaciju.";
		String[] podjela = komanda.split(" ");
		if (podjela[0].equals("izracun")) {
			odgovor = priprema(komanda);
		}
		if (podjela[0].equals("SPREMI") || podjela[0].equals("spremi)")) {
			serijalizacija(listaZahtjeva);
			odgovor = "OK Provedena je serijalizacija.";
		}
		listaZahtjeva.add(podjela);
		return odgovor;
	}

	/**
	 * oblikuje predmetni dio poruke u format za obradu
	 *
	 * @param String zadana naredba
	 * @return ako lokacije postoje, vraća udaljenost između dviju lokacija izraženu
	 *         u kilometrima
	 */
	private static String priprema(String komanda) {
		String odgovor = "";
		String[] podjela = komanda.split(" ");

		float duljina1 = Float.parseFloat(podjela[1]);
		float sirina1 = Float.parseFloat(podjela[2]);

		float duljina2 = Float.parseFloat(podjela[3]);
		float sirina2 = Float.parseFloat(podjela[4]);

		double udaljenost = 0;
		udaljenost = udaljenostIzracun(duljina1, sirina1, duljina2, sirina2);
		DecimalFormat df = new DecimalFormat("#.#");
		odgovor = df.format(udaljenost);

		return odgovor;
	}

	/**
	 * Računa udaljenost lokacija po Haversinovoj formuli
	 * proučena implementacija na stranici:
	 * @see <a>https://www.geeksforgeeks.org/haversine-formula-to-find-distance-between-two-points-on-a-sphere</a>
	 * 
	 * @param duljina1 geografska duljina prve lokacije
	 * @param sirina1  geografska širina prve lokacije
	 * @param duljina2 geografska duljina druge lokacije
	 * @param sirina2  geografska širina druge lokacije
	 * @return the double
	 * 
	 *         {@linkhttps://www.geeksforgeeks.org/haversine-formula-to-find-distance-between-two-points-on-a-sphere/}
	 */
	private static double udaljenostIzracun(float duljina1, float sirina1, float duljina2, float sirina2) {
		double udaljenost = 0;
		double dLat = Math.toRadians(sirina2 - sirina1);
		double dLon = Math.toRadians(duljina2 - duljina1);
		double stupnjevi = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(Math.toRadians(duljina1))
				* Math.cos(Math.toRadians(duljina2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
		double nekaVarijabla = 2 * Math.atan2(Math.sqrt(stupnjevi), Math.sqrt(1 - stupnjevi));
		udaljenost = 6371.01 * nekaVarijabla;
		return udaljenost;
	}

	/**
	 * metoda serijalizacije podataka
	 * 
	 * @see <a>linkhttps://www.tutorialspoint.com/java/java_serialization.html </a>
	 * @param listaZahtjeva lista u kojoj su pohranjeni svi dosadašnji zahtjevi
	 *                      prema poslužitelju udaljenosti
	 */
	public static void serijalizacija(List<String[]> listaZahtjeva) {
		File f = new File(imeDatoteteSerijalizacije);
		if (f.exists() && !f.isDirectory()) {
			try {
				FileOutputStream fos = new FileOutputStream(imeDatoteteSerijalizacije);
				ObjectOutputStream oos = new ObjectOutputStream(fos);
				oos.writeObject(listaZahtjeva);
				oos.close();
				Logger.getLogger(PosluziteljUdaljenosti.class.getName()).log(Level.INFO,
						"OK, serijalizacija provedena.");
			} catch (IOException e) {
				Logger.getLogger(PosluziteljUdaljenosti.class.getName()).log(Level.WARNING,
						"ERROR 19: Greška kod serijalizacije. " + e.getMessage());
			}
		}
	}

	/**
	 * metoda deserijalizacije
	 * 
	 * proučen način deserijalizacije na stranici
	 * 
	 * @see <a> inkhttps://www.tutorialspoint.com/java/java_serialization.html </a>
	 * @param imeDatoteteSerijalizacije the ime datotete serijalizacije
	 */
	public static void deserijalizacija(String imeDatoteteSerijalizacije) {
		try {
			FileInputStream fis;
			fis = new FileInputStream(imeDatoteteSerijalizacije);
			ObjectInputStream ins = new ObjectInputStream(fis);
			listaZahtjeva = (List<String[]>) ins.readObject();
			ins.close();
			fis.close();
			String ispisivanje = "";
			if (ispis == 1) {
				for (String[] zapis : listaZahtjeva) {
					ispisivanje = String.join(" ", zapis);
					Logger.getGlobal().log(Level.INFO, ispisivanje);
				}
			}
		} catch (Exception e) {
			Logger.getLogger(PosluziteljUdaljenosti.class.getName()).log(Level.WARNING,
					"ERROR 19: Greška kod deserijalizacije. Nema podataka u datoteci. " + e.getMessage());
		}

	}
}

//java -cp target/dkusic_zadaca_1_app-1.0.0.jar org.foi.nwtis.dkusic.zadaca_1.PosluziteljUdaljenosti NWTiS_dkusic_2.txt