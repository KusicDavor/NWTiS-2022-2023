package org.foi.nwtis.dkusic.zadaca_1;

import java.io.IOException;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.SocketException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.Konfiguracija;
import org.foi.nwtis.dkusic.zadaca_1.podaci.Korisnik;
import org.foi.nwtis.dkusic.zadaca_1.podaci.Lokacija;
import org.foi.nwtis.dkusic.zadaca_1.podaci.Uredaj;
import org.foi.nwtis.dkusic.zadaca_1.pomocnici.CitanjeKorisnika;

/**
 * Klasa GlavniPosluzitelj koja je zadužena za otvaranje veze na određenim
 * mrežnim vratima/portu.
 */
public class GlavniPosluzitelj {

	/** Konfiguracija. */
	protected Konfiguracija konfig;

	/** Uređaji. */
	protected Map<String, Uredaj> uredaji;

	/** Lokacije. */
	protected Map<String, Lokacija> lokacije;

	/** Korisnici . */
	protected Map<String, Korisnik> korisnici;

	/** The ispis. */
	private int ispis;
	
	/** The maks cekanje. */
	private int maksCekanje;
	
	/** The mrezna vrata. */
	private int mreznaVrata;
	
	/** The broj cekaca. */
	private int brojCekaca;
	
	/** The kraj rada. */
	public static boolean krajRada;

	/**
	 * Instancira klasu GlavniPosluzitelj uz danu konfiguraciju.
	 *
	 * @param konfig Konfiguracija
	 */
	public GlavniPosluzitelj(Konfiguracija konfig) {
		super();
		this.konfig = konfig;
		this.maksCekanje = Integer.parseInt(this.konfig.dajPostavku("maksCekanje"));
		this.ispis = Integer.parseInt(this.konfig.dajPostavku("ispis"));
		this.mreznaVrata = Integer.parseInt(this.konfig.dajPostavku("mreznaVrata"));
		this.brojCekaca = Integer.parseInt(this.konfig.dajPostavku("brojCekaca"));
		GlavniPosluzitelj.krajRada = false;
	}

	/**
	 * Pokreni poslužitelja.
	 */
	public void pokreniPosluzitelj() {
		ucitavanjaPodataka();
		otvoriMreznaVrata();
	}

	/**
	 * Ucitavanja podataka.
	 */
	public void ucitavanjaPodataka() {
		try {
			ucitajKorisnike();
			ucitajUredaje();
			ucitajLokacije();
		} catch (IOException e) {
			Logger.getGlobal().log(Level.SEVERE, e.getMessage());
		}
	}

	/**
	 * Ucitaj korisnike iz datoteke.
	 *
	 * @throws IOException Okida se kad se pojavi problem s datotekom
	 */
	public void ucitajKorisnike() throws IOException {
		var nazivDatoteke = this.konfig.dajPostavku("datotekaKorisnika");
		var citac = new CitanjeKorisnika();
		this.korisnici = citac.ucitajDatoteku(nazivDatoteke);
		if (this.ispis == 1) {
			for (String k : this.korisnici.keySet()) {
				var korisnik = this.korisnici.get(k);
				Logger.getGlobal().log(Level.INFO,
						"Korisnik = prezime: " + korisnik.prezime() + " ime: " + korisnik.ime());
			}
		}
	}

	/**
	 * Ucitaj uredaje.
	 *
	 * @throws IOException Okida se kad se pojavi problem s datotekom
	 */
	public void ucitajUredaje() throws IOException {
		var nazivDatoteke = this.konfig.dajPostavku("datotekaUredaja");
		var citac = new CitanjeUredaja();
		this.uredaji = citac.ucitajDatoteku(nazivDatoteke);
		if (this.ispis == 1) {
			for (String k : this.uredaji.keySet()) {
				var uredaj = this.uredaji.get(k);
				Logger.getGlobal().log(Level.INFO,
						"Uređaj = ID uređaja: " + uredaj.id() + " Vrsta uređaja: " + uredaj.vrsta() + "");
			}
		}
	}

	/**
	 * Ucitaj lokacije.
	 *
	 * @throws IOException Okida se kad se pojavi problem s datotekom
	 */
	public void ucitajLokacije() throws IOException {
		var nazivDatoteke = this.konfig.dajPostavku("datotekaLokacija");
		var citac = new CitanjeLokacije();
		this.lokacije = citac.ucitajDatoteku(nazivDatoteke);
		if (this.ispis == 1) {
			for (String k : this.lokacije.keySet()) {
				var lokacija = this.lokacije.get(k);
				Logger.getGlobal().log(Level.INFO,
						"Lokacija = ID lokacije: " + lokacija.id() + " Naziv lokacije: " + lokacija.naziv() + "");
			}
		}
	}

	/**
	 * Otvori mrezna vrata.
	 */
	public void otvoriMreznaVrata() {
		try (var posluzitelj = new ServerSocket(this.mreznaVrata, this.brojCekaca)) {
			posluzitelj.setSoTimeout(maksCekanje);
			krajRada = false;
			while (!GlavniPosluzitelj.krajRada) {
				var uticnica = posluzitelj.accept();
				var dretva = new MrezniRadnik(uticnica, this.konfig);
				dretva.start();
				dretva.join();
			}
		} catch (BindException e) {
			Logger.getGlobal().log(Level.WARNING, "ERROR 29: Zauzeće porta. " + e.getMessage());
		} catch (SocketException e) {
			Logger.getGlobal().log(Level.WARNING, "ERROR 29: Isteklo vrijeme čekanja. " + e.getMessage());
		} catch (IOException e) {
			Logger.getGlobal().log(Level.WARNING, "ERROR 29: Greška s pokretanjem dretve. " + e.getMessage());
		} catch (InterruptedException e) {
			Logger.getGlobal().log(Level.WARNING, "ERROR 29: Dretva prekinuta. " + e.getMessage());
		}
	}

	/**
	 * Ugasi glavnog poslužitelja
	 */
	public void zatvori() {
		krajRada = true;
		Runtime.getRuntime().addShutdownHook(new Thread());
	}
}
//java -cp target/dkusic_zadaca_1_app-1.0.0.jar org.foi.nwtis.dkusic.zadaca_1.PokretacPosluzitelja NWTiS_dkusic_3.txt