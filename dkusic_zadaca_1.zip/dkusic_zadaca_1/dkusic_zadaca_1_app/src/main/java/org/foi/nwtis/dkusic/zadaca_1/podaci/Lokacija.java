package org.foi.nwtis.dkusic.zadaca_1.podaci;

/**
 * zapis Lokacija služi za kreiranje objekta koji predstavlja lokaciju
 */
public record Lokacija(String naziv, String id, String gpsSirina, String gpsDuzina) {

}
