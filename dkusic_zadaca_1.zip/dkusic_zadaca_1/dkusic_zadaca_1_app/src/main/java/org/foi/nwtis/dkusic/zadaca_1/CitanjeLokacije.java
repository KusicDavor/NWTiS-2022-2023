package org.foi.nwtis.dkusic.zadaca_1;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.foi.nwtis.dkusic.zadaca_1.podaci.Lokacija;

/**
 * Intancira klasu CitanjeLokacije koja služi za učitavanje lokacija i spremanje
 * na glavni poslužitelj.
 */
public class CitanjeLokacije {

	/**
	 * Ucitaj datoteku.
	 *
	 * @param nazivDatoteke naziv datoteke koja sadrži podatke o lokacijama
	 * @return map koji sadrži sve lokacije
	 * @throws IOException Ako je čitanje bilo neuspješno.
	 */
	public Map<String, Lokacija> ucitajDatoteku(String nazivDatoteke) throws IOException {
		var putanja = Path.of(nazivDatoteke);
		if (!Files.exists(putanja) || Files.isDirectory(putanja) || !Files.isReadable(putanja)) {
			throw new IOException("Datoteka '" + nazivDatoteke + "' nije datoteka ili nije moguće čitati.");
		}
		var lokacije = new HashMap<String, Lokacija>();
		var citac = Files.newBufferedReader(putanja, Charset.forName("UTF-8"));

		while (true) {
			var redak = citac.readLine();
			if (redak == null) {
				break;
			}
			var odsjek = redak.split(";");
			if (odsjek.length != 4) {
				Logger.getGlobal().log(Level.WARNING, "ERROR 29: Greška u datoteci s podacima uređaja.");
			} else {
				var lokacija = new Lokacija(odsjek[0], odsjek[1], odsjek[2], odsjek[3]);
				lokacije.put(odsjek[1], lokacija);
			}
		}
		return lokacije;
	}
}
