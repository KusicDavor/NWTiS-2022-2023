package org.foi.nwtis.dkusic.zadaca_1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Instancira klasu GlavniKlijent koja služi klijentu za komunikaciju s
 * poslužiteljima.
 */
public class GlavniKlijent {

	/** varijabla prekid služi za prekidanje rada klijenta */
	private static boolean prekid = false;

	/**
	 * Glavna metoda klijenta
	 *
	 * @param args prima argumente i opcije za pokretanje
	 * @throws NumberFormatException baca pogrešku ako uneseni argument nije broj
	 * @throws IOException           baca pogrešku ako je spajanje na poslužitelj bilo neuspješno
	 * 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		try {
			String adresa = args[5];
			int mreznaVrata = Integer.parseInt(args[7]);
			int cekanjeOdg = Integer.parseInt(args[9]);
			String autentikacijski = "";
			String predmetni = "";
			String komanda = "";
			var GlavniKlijent = new GlavniKlijent();
			boolean ispravni = TestOpcijaGlavniKlijent.main(args);
			if (!ispravni) {
				Logger.getLogger(GlavniKlijent.class.getName()).log(Level.WARNING,
						"ERROR 20: Format komande nije ispravan.");
			} else {
				adresa = args[5];
				mreznaVrata = Integer.parseInt(args[7]);
				cekanjeOdg = Integer.parseInt(args[9]);
				autentikacijski = autent(args);
				predmetni = predmet(args, 10);
				komanda = autentikacijski + " " + predmetni;
				GlavniKlijent.spojiSeNaPosluzitelj(adresa, mreznaVrata, cekanjeOdg, komanda);
			}
			while (!prekid) {
				Scanner sc = new Scanner(System.in);
				String novaKomanda = sc.nextLine();
				String[] poljeArgumenata = novaKomanda.split(" ");
				autentikacijski = autent(poljeArgumenata);

				if (poljeArgumenata.length > 10) {
					predmetni = predmet(poljeArgumenata, 10);
				} else {
					predmetni = predmet(poljeArgumenata, 4);
				}

				komanda = autentikacijski + " " + predmetni;
				boolean provjeri = TestOpcijaGlavniKlijent.main(poljeArgumenata);
				if (provjeri) {
					GlavniKlijent.spojiSeNaPosluzitelj(adresa, mreznaVrata, cekanjeOdg, komanda);
				} else {
					Logger.getLogger(GlavniKlijent.class.getName()).log(Level.WARNING,
							"ERROR 20: Format komande nije ispravan.");
				}
			}
		} catch (SocketException e) {
			Logger.getGlobal().log(Level.WARNING, "ERROR 29: Poslužitelj je zatvoren. " + e.getMessage(),
					StandardCharsets.UTF_8);
		} catch (UnknownHostException e) {
			Logger.getGlobal().log(Level.WARNING, "ERROR 29: Nepoznata adresa poslužitelja. " + e.getMessage(),
					StandardCharsets.UTF_8);
		} catch (ArrayIndexOutOfBoundsException e) {
			Logger.getLogger(GlavniKlijent.class.getName()).log(Level.WARNING,
					"ERROR 20: Format komande nije ispravan.");
		}
	}

	/**
	 * metoda za razdvajanje unesene naredbe na predmetni dio 
	 *
	 * @param args argumenti predmetnog dijela
	 * @param indeks označava prvi argument predmetnog dijela u komandi
	 * @return predmetni dio naredbe
	 */
	private static String predmet(String[] args, int indeks) {
		String predmetni = "";
		for (int i = indeks; i < args.length; i++) {
			predmetni += args[i] + " ";
		}
		return predmetni;
	}

	/**
	 * metoda za razdvajanje unesene naredbe na autorizacijski dio 
	 *
	 * @param args argumenti autentikacijskog dijela
	 * @return autentikacijski dio naredbe
	 */
	private static String autent(String[] args) {
		String autentikacijski = "";
		autentikacijski += args[1] + " " + args[3];
		return autentikacijski;
	}

	/**
	 * Spajanje na glavnog poslužitelja.
	 *
	 * @param adresa      adresa poslužitelja
	 * @param mreznaVrata mrežna vrata (port) poslužitelja
	 * @param cekanjeOdg  vrijeme čekanja na odgovor
	 * @param komanda     unesena naredba
	 * @throws IOException pogreška u slučaju neuspješne komunikacije sa poslužiteljem
	 */
	public void spojiSeNaPosluzitelj(String adresa, int mreznaVrata, int cekanjeOdg, String komanda)
			throws IOException {
		try {
			var mreznaUticnica = new Socket();
			InetSocketAddress socketAdress = new InetSocketAddress(adresa, mreznaVrata);
			mreznaUticnica.connect(socketAdress, cekanjeOdg);
			var citac = new BufferedReader(
					new InputStreamReader(mreznaUticnica.getInputStream(), Charset.forName("UTF-8")));
			var pisac = new BufferedWriter(
					new OutputStreamWriter(mreznaUticnica.getOutputStream(), Charset.forName("UTF-8")));
			pisac.write(komanda);
			pisac.flush();
			mreznaUticnica.shutdownOutput();
			var poruka = new StringBuilder();
			while (true) {
				var redak = citac.readLine();
				if (redak == null) {
					break;
				}
				Logger.getGlobal().log(Level.INFO, redak);
				poruka.append(redak);
			}
			mreznaUticnica.shutdownInput();
			mreznaUticnica.close();
		} catch (ConnectException e) {
			Logger.getGlobal().log(Level.WARNING, "ERROR 29: Pogreška pri spajanju na poslužitelj. " + e.getMessage(),
					StandardCharsets.UTF_8);
			prekid = true;
		} catch (IllegalArgumentException e) {
			Logger.getGlobal().log(Level.WARNING,
					"ERROR 29: Glavni klijent nije ispravno pokrenut. Nedostaju podaci za povezivanje na server. "
							+ e.getMessage(),
					StandardCharsets.UTF_8);
			prekid = true;
		} catch (SocketTimeoutException e) {
			Logger.getGlobal().log(Level.WARNING,
					"ERROR 29: Isteklo vrijeme čekanja na poslužitelja. " + e.getMessage(), StandardCharsets.UTF_8);
			prekid = true;
		}
	}
}
//java -cp target/dkusic_zadaca_1_app-1.0.0.jar org.foi.nwtis.dkusic.zadaca_1.GlavniKlijent -k pkos -l 123456 -a localhost -v 8000 -t 0 --meteo FOI1-DHT11