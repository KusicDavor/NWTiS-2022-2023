package org.foi.nwtis.dkusic.zadaca_1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.foi.nwtis.Konfiguracija;
import org.foi.nwtis.dkusic.zadaca_1.podaci.Korisnik;
import org.foi.nwtis.dkusic.zadaca_1.podaci.Lokacija;
import org.foi.nwtis.dkusic.zadaca_1.podaci.Uredaj;

/**
 * Klasa MrezniRadnik koja je tipa Thread
 */
public class MrezniRadnik extends Thread {

	/** Mrežna utičnica za spajanje na poslužitelje */
	protected Socket mreznaUticnica = null;

	/** Konfiguracijska datoteka */
	protected Konfiguracija konfig = null;

	/**
	 * Atribut ispis označava potrebu za ispisom tekućeg podatka pri radu programa
	 */
	private int ispis = 0;

	/**
	 * Klasa glavnog poslužitelja koja se prosljeđuje pri kreiranju nove dretve
	 * MrezniRadnik
	 */
	GlavniPosluzitelj gp = null;

	/** brojac aktivnih dretvi */
	private volatile static int brojacDretvi = 1;

	/** lista svih mjerenja (simulacija) koji dolazi sa SimulatorMeteo */
	private static List<String[]> listaMeteo = new ArrayList<String[]>();

	/** lista svih alarmova */
	private static List<String[]> listaAlarm = new ArrayList<String[]>();

	/** pomoćna lista za pomoć pri brisanju starijih zapisa simulacija */
	private static List<String[]> listaObrisati = new ArrayList<String[]>();

	/**
	 * Instancira novu dretvu MrezniRadnik
	 *
	 * @param mreznaUticnica mrežna utičnica (port poslužitelja)
	 * @param konfig         konfiguracijska datoteka
	 */
	public MrezniRadnik(Socket mreznaUticnica, Konfiguracija konfig) {
		super("dkusic_" + (brojacDretvi));
		this.setName("dkusic_" + brojacDretvi++);
		this.mreznaUticnica = mreznaUticnica;
		this.konfig = konfig;
		this.ispis = Integer.parseInt(this.konfig.dajPostavku("ispis"));
		synchronized (this) {
			brojacDretvi++;
		}
	}

	/**
	 * pokreće rad dretve
	 */
	@Override
	public synchronized void start() {
		super.start();
	}

	/**
	 * metoda izvršavanje dretve nakon pokretanja
	 */
	@Override
	public void run() {
		this.gp = new GlavniPosluzitelj(konfig);
		gp.ucitavanjaPodataka();

		try {
			var citac = new BufferedReader(
					new InputStreamReader(this.mreznaUticnica.getInputStream(), Charset.forName("UTF-8")));
			var pisac = new BufferedWriter(
					new OutputStreamWriter(this.mreznaUticnica.getOutputStream(), Charset.forName("UTF-8")));
			var poruka = new StringBuilder();
			while (true) {
				var redak = citac.readLine();
				if (redak == null) {
					break;
				}
				Logger.getGlobal().log(Level.INFO, redak);

				poruka.append(redak);
			}
			this.mreznaUticnica.shutdownInput();
			var odgovor = this.obradiZahtjev(poruka.toString());
			pisac.write(odgovor);
			pisac.flush();
			this.mreznaUticnica.shutdownOutput();
			this.mreznaUticnica.close();
		} catch (IOException | InterruptedException e) {
			Logger.getLogger(MrezniRadnik.class.getName()).log(Level.WARNING,
					"ERROR 29: Pogreška kod obrade upita. " + e.getMessage());
		}

		synchronized (this) {
			brojacDretvi--;
		}
	}

	/**
	 * Obradi zahtjev.
	 *
	 * @param poruka unesena naredba na koju korisnik traži obradu i odgovor
	 * @return odgovor na zahtjev
	 * @throws InterruptedException the interrupted exception
	 * @throws IOException          Signals that an I/O exception has occurred.
	 */
	public synchronized String obradiZahtjev(String poruka) throws InterruptedException, IOException {
		String[] polje = poruka.split(" ");
		String autent = "";
		String predmet = "";
		if (sintaksaKomande(polje[0], "KORISNIK") && sintaksaKomande(polje[2], "LOZINKA")
				&& (sintaksaKomande(polje[4], "SENZOR") || sintaksaKomande(polje[4], "METEO"))) {
			autent = polje[1] + " " + polje[3];
			for (int i = 4; i < polje.length; i++) {
				predmet += polje[i] + " ";
			}
		} else if (sintaksaKomande(polje[0], "KORISNIK") && sintaksaKomande(polje[2], "LOZINKA")
				&& (sintaksaKomande(polje[3], "[\\w-]+"))) {
			autent = polje[1] + " " + polje[3];
			for (int i = 4; i < polje.length; i++) {
				predmet += polje[i] + " ";
			}
		} else {
			autent = polje[0] + " " + polje[1];
			for (int i = 2; i < polje.length; i++) {
				predmet += polje[i] + " ";
			}
		}

		String odgovor;
		String odgovorAutent = autentikacija(autent);
		if (odgovorAutent.equals("OK")) {
			String odgovorPredmet = podjela(predmet);
			odgovor = odgovorPredmet;
		} else {
			odgovor = odgovorAutent;
		}
		return odgovor;
	}

	/**
	 * Sintaksa komande, metoda koristi regex za određivanje formata i arguemenata u
	 * dobivenoj naredbi
	 *
	 * @param predmet predmetni dio naredbe
	 * @param izraz   izraz s kojim se argument ili vrijednost uspoređuju
	 * @return vraća true ako je regex uvjet zadovoljen
	 */
	public boolean sintaksaKomande(String predmet, String izraz) {
		Pattern p = Pattern.compile(izraz);
		Matcher m = p.matcher(predmet);

		return m.matches();
	}

	/**
	 * Podjela - provjerava predmetni dio naredbe s regex uzorkom i poziva
	 * odgovarajuću metodu za obradu naredbe
	 *
	 * @param predmet predmetni dio naredbe
	 * @return odgovor vraća odgovor na postavljeni upit
	 * @throws InterruptedException baca pogrešku ako dođe do prekida tijekom obrade
	 * @throws IOException          Signals baca pogrešku ako dođe do prekida pri
	 *                              radu s argumentima ili komunikaciji
	 */
	public synchronized String podjela(String predmet) throws InterruptedException, IOException {
		String odgovor = "ERROR 29: POGREŠKA U OBRADI NAREDBE";
		String[] podjela = predmet.split(" ");

		if (sintaksaKomande(podjela[0], "--kraj") || sintaksaKomande(podjela[0], "KRAJ")) {
			odgovor = "OK";
			gp.zatvori();
		}

		if (sintaksaKomande(podjela[0], "ALARM") || (sintaksaKomande(podjela[0], "--alarm"))) {
			odgovor = pokaziAlarm(podjela);
		}

		if (sintaksaKomande(podjela[0], "UDALJENOST") && podjela.length == 2) {
			odgovor = puSpremanje(podjela);
		}

		if (sintaksaKomande(podjela[0], "--udaljenost") && podjela.length == 2) {
			odgovor = puSpremanje(podjela);
		}

		if (sintaksaKomande(podjela[0], "--udaljenost") && podjela.length > 2) {
			odgovor = udaljenost(podjela);
		}

		if (sintaksaKomande(podjela[0], "UDALJENOST") && podjela.length > 2) {
			odgovor = udaljenost(podjela);
		}

		if (sintaksaKomande(podjela[0], "[\\w-]+")
				&& sintaksaKomande(podjela[1], "([1-9]|1[0-9]|2[0-3]|0):([0-9]|[1-5][0-9]):([0-9]|[1-5][0-9])")) {
			odgovor = provjeraID(podjela[0]);
			if (odgovor.equals("OK")) {
				String meteo = "";
				for (int i = 0; i < podjela.length; i++) {
					meteo += podjela[i] + " ";
				}
				pohraniMeteo(meteo);
				odgovor = "POHRANJEN ----- " + meteo;
			}
		}

		if (sintaksaKomande(podjela[0], "SENZOR") && sintaksaKomande(podjela[1], "[\\w-]+")
				&& sintaksaKomande(podjela[2], "([1-9]|1[0-9]|2[0-3]|0):([0-9]|[1-5][0-9]):([0-9]|[1-5][0-9])")) {
			odgovor = provjeraID(podjela[1]);
			if (odgovor.equals("OK")) {
				odgovor = provjeraTipaUredaja(podjela);
				if (odgovor.equals("OK")) {
					odgovor = dohvatiZapise(podjela);
				}
			}
		}

		if (sintaksaKomande(podjela[0], "MAKS")) {
			odgovor = "ERROR: Uređaj postoji ali nema podataka o mjerenju.";
			odgovor = provjeraID(podjela[2]);
			if (odgovor.equals("OK")) {
				switch (podjela[1]) {
				case "TEMP": {
					int indeks = 2;
					odgovor = dohvatiMaks(podjela, indeks);
					break;
				}
				case "VLAGA": {
					int indeks = 3;
					odgovor = dohvatiMaks(podjela, indeks);
					break;
				}
				case "TLAK": {
					int indeks = 4;
					odgovor = dohvatiMaks(podjela, indeks);
					break;
				}
				}
			}
			return odgovor;
		}

		if (sintaksaKomande(podjela[0], "--makstemp")) {
			odgovor = "ERROR: Uređaj postoji ali nema podataka o mjerenju.";
			odgovor = provjeraID(podjela[1]);
			if (odgovor.equals("OK")) {
				int indeks = 2;
				String polje[] = new String[3];
				polje[2] = podjela[1];
				odgovor = dohvatiMaks(polje, indeks);
			}
			return odgovor;
		}

		if (sintaksaKomande(podjela[0], "--maksvlaga")) {
			odgovor = "ERROR: Uređaj postoji ali nema podataka o mjerenju.";
			odgovor = provjeraID(podjela[1]);
			if (odgovor.equals("OK")) {
				int indeks = 3;
				String polje[] = new String[3];
				polje[2] = podjela[1];
				odgovor = dohvatiMaks(polje, indeks);
			}
			return odgovor;
		}

		if (sintaksaKomande(podjela[0], "--makstlak")) {
			odgovor = "ERROR: Uređaj postoji ali nema podataka o mjerenju.";
			odgovor = provjeraID(podjela[1]);
			if (odgovor.equals("OK")) {
				int indeks = 4;
				String polje[] = new String[3];
				polje[2] = podjela[1];
				odgovor = dohvatiMaks(polje, indeks);
			}
			return odgovor;
		}

		if ((sintaksaKomande(podjela[0], "--meteo") || sintaksaKomande(podjela[0], "METEO"))
				&& sintaksaKomande(podjela[1], "[\\w-]+")) {
			odgovor = provjeraID(podjela[1]);
			if (odgovor.equals("OK")) {
				odgovor = traziSenzor(podjela[1]);
			}
		}

		return odgovor;
	}

	/**
	 * metoda šalje naredbu u PosluziteljUdaljenosti i traži serijalizaciju
	 * pohranjenih narebi
	 *
	 * @param podjela predmetni dio izvorne naredbe
	 * @return odgovor - uspješna ili neuspješna serijalizacija
	 * @throws baca pogrešku ako dođe do prekida pri radu s argumentima ili
	 *              komunikaciji
	 */
	private String puSpremanje(String[] podjela) throws IOException {
		String odgovor = "";
		String komanda = "SPREMI";
		String adresaPU = this.konfig.dajPostavku("posluziteljUdaljenostiAdresa");
		int port = Integer.parseInt(this.konfig.dajPostavku("posluziteljUdaljenostiVrata"));
		odgovor = poveziPU(adresaPU, port, komanda);
		return odgovor;
	}

	/**
	 * metoda šalje naredbu u PosluziteljUdaljenosti i izračun udaljenosti između
	 * danih lokacija
	 *
	 * @param podjela predmetni dio izvorne naredbe
	 * @return udaljenost između lokacija ako lokacije postoje
	 * @throws baca pogrešku ako dođe do prekida pri radu s argumentima ili
	 *              komunikaciji
	 */
	private String udaljenost(String[] podjela) throws IOException {
		String izracun = "izracun";
		String odgovor = "";
		String adresaPU = this.konfig.dajPostavku("posluziteljUdaljenostiAdresa");
		int port = Integer.parseInt(this.konfig.dajPostavku("posluziteljUdaljenostiVrata"));
		String[] pripremi = new String[3];
		pripremi[0] = podjela[0];
		pripremi[1] = podjela[1];
		pripremi[2] = podjela[2];
		Lokacija lokacija1 = vratiLokaciju(pripremi);
		if (lokacija1 != null) {
			String lok1 = lokacija1.gpsDuzina() + " " + lokacija1.gpsSirina();
			try {
				pripremi[1] = podjela[3];
				pripremi[2] = podjela[4];
			} catch (Exception e) {
				Logger.getGlobal().log(Level.WARNING, "ERROR 29: Pogrešno upisana lokacija. " + e.getMessage(),
						StandardCharsets.UTF_8);
			}
			Lokacija lokacija2 = vratiLokaciju(pripremi);

			if (lokacija2 != null) {
				String lok2 = lokacija2.gpsDuzina() + " " + lokacija2.gpsSirina();
				String komanda = izracun + " " + lok1 + " " + lok2;
				odgovor = poveziPU(adresaPU, port, komanda);
			} else {
				odgovor = "Druga lokacija ne postoji";
			}
		} else {
			odgovor = "Prva lokacija ne postoji";
		}
		return odgovor;
	}

	/**
	 * metoda za povezivanje sa PosluziteljUdaljenosti
	 *
	 * @param adresaPU adresa na kojoj se nalazi PosluziteljUdaljenosti
	 * @param port     mrežna vrata (port) PosluziteljaUdaljenosti
	 * @param naredba  koju šaljemo na PosluziteljUdaljenosti
	 * @return komanda vraća odgovor poslužitelja na poslani zahtjev
	 * @throws baca pogrešku ako dođe do prekida pri radu s argumentima ili
	 *              komunikaciji
	 */
	private String poveziPU(String adresaPU, int port, String komanda) throws IOException {
		String odgovor = "ERROR 25: Poslužitelj udaljenosti ne radi.";
		try {
			var uticnicaPU = new Socket();
			InetSocketAddress socketAdress = new InetSocketAddress(adresaPU, port);
			uticnicaPU.connect(socketAdress);
			var citac = new BufferedReader(
					new InputStreamReader(uticnicaPU.getInputStream(), Charset.forName("UTF-8")));
			var pisac = new BufferedWriter(
					new OutputStreamWriter(uticnicaPU.getOutputStream(), Charset.forName("UTF-8")));
			pisac.write(komanda);
			pisac.flush();
			uticnicaPU.shutdownOutput();
			var poruka = new StringBuilder();
			while (true) {
				var redak = citac.readLine();
				if (redak == null) {
					break;
				}
				poruka.append(redak);
			}
			uticnicaPU.shutdownInput();
			uticnicaPU.close();
			odgovor = poruka.toString();
		} catch (ConnectException e) {
			Logger.getGlobal().log(Level.WARNING, "ERROR 25: Poslužitelj udaljenosti ne radi. " + e.getMessage(),
					StandardCharsets.UTF_8);
		}
		return odgovor;
	}

	/**
	 * metoda provjerava lokaciju i ID uređaja nakon čega šalje posljednji alarm
	 * traženog urešaja
	 *
	 * @param predmetni dio naredbe
	 * @return odgovor na upit, započienje traženje posljednjeg alarma uređaja ako
	 *         postoji ili
	 */
	private String pokaziAlarm(String[] podjela) {
		String odgovor = "Za lokaciju ne postoji alarm.";
		odgovor = provjeriLokaciju(podjela);
		if (odgovor.equals("OK")) {
			odgovor = vratiAlarm(podjela);
		}
		return odgovor;
	}

	/**
	 * metoda za detekciju posljednjeg alarma koji odgovara traženom ID uređaja i
	 * lokaciji
	 *
	 * @param podjela predmetni dio naredbe
	 * @return vraća posljednji alarm uređaja, ako alarm postoji vraća "OK"
	 */
	private String vratiAlarm(String[] podjela) {
		String odgovor = "OK";
		String lok = "";
		for (int i = 1; i < podjela.length; i++) {
			lok += podjela[i] + " ";
		}
		int mvrijeme = 0;
		lok = lok.replace("'", "").trim();
		for (String[] meteo : listaAlarm) {
			for (Uredaj uredaj : gp.uredaji.values()) {
				if (lok.equals(uredaj.idLokacija()) && meteo[0].equals(uredaj.id())) {
					odgovor = "OK";
					if (mvrijeme > pretvorbaVremena((meteo[1]).trim())) {
						break;
					} else {
						mvrijeme = pretvorbaVremena((meteo[1]).trim());
						for (int i = 0; i < meteo.length; i++) {
							if (meteo[i] == null) {
								if (meteo[i] == null) {
									break;
								}
								odgovor += " " + meteo[i];
							}
						}
					}
				}
			}
		}
		if (odgovor.equals("OK")) {
			odgovor = "Ne postoji alarm za danu lokaciju.";
		}
		odgovor.trim();
		return odgovor;
	}

	/**
	 * Provjeri lokaciju - metoda za provjeru postojanja lokacije
	 *
	 * @param podjela predmetni dio naredbe
	 * @return ako lokacija postoji vraća "OK", u suprotnom grešku
	 */
	private String provjeriLokaciju(String[] podjela) {
		String lok = "";
		for (int i = 1; i < podjela.length; i++) {
			lok += podjela[i] + " ";
		}
		lok = lok.trim().replace("'", "");
		String odgovor = "";
		for (Lokacija l : gp.lokacije.values()) {
			if (l.id().equals(lok)) {
				odgovor = "OK";
				break;
			} else {
				odgovor = "ERROR 24: Lokacija ne postoji.";
			}
		}
		return odgovor;
	}

	/**
	 * metoda vraća lokaciju
	 *
	 * @param podjela predmetni dio naredbe
	 * @return lokacija ako je ispravna i tražena naredbom
	 */
	private Lokacija vratiLokaciju(String[] podjela) {
		String lok = "";
		Lokacija lokacija = null;
		for (int i = 1; i < podjela.length; i++) {
			lok += podjela[i] + " ";
		}
		lok = lok.trim().replace("'", "");
		for (Lokacija l : gp.lokacije.values()) {
			if (l.id().equals(lok)) {
				lokacija = l;
				break;
			}
		}
		return lokacija;
	}

	/**
	 * Provjera tipa uredaja - metoda provjerava tip uređaja, potrebno je ustanoviti
	 * broj argumenata koji uređaj prima
	 *
	 * @param podjela predmetni dio naredbe
	 * @return "OK" ako uređaj postoji
	 */
	private String provjeraTipaUredaja(String[] podjela) {
		String odgovor = "";

		for (Uredaj uredaj : gp.uredaji.values()) {
			if (uredaj.id().equals(podjela[1])) {
				odgovor = "OK";
				break;
			} else {
				odgovor = "ERROR 29: Uređaj je pogrešne vrste.";
			}
		}
		return odgovor;
	}

	/**
	 * Dohvati zapise.
	 *
	 * @param podjela predmetni dio naredbe
	 * @return odgovor na naredbu SENZOR, aktivira alarm, sprema zapise, vraća
	 * @throws IOException baca pogrešku ako dođe do prekida pri radu s argumentima
	 *                     ili komunikaciji
	 */
	private String dohvatiZapise(String[] podjela) throws IOException {
		float odstupanjeTemp = Float.parseFloat(this.konfig.dajPostavku("odstupanjeTemp"));
		float odstupanjVlaga = Float.parseFloat(this.konfig.dajPostavku("odstupanjVlaga"));
		float odstupanjeTlak = Float.parseFloat(this.konfig.dajPostavku("odstupanjeTlak"));
		int brojArgumenata = podjela.length - 1;
		float temperatura = 0;
		float vlaga = 0;
		float tlak = 0;
		boolean upaliAlarm = false;
		boolean prekidVrijeme = false;
		String[] zaUpis = null;
		String odgovor = "Nije upaljen nijedan novi alarm.";

		for (String[] meteo : listaMeteo) {

			int vrijeme1 = pretvorbaVremena((meteo[1]).trim());
			int vrijeme2 = pretvorbaVremena((podjela[2]).trim());

			if (vrijeme1 == vrijeme2 && podjela[1].equals(meteo[0])) {
				if (meteo.length != brojArgumenata) {
					odgovor = "ERROR 29: Unesen pogrešan broj argumenata. Senzor prima " + (meteo.length - 1)
							+ " argumenta.";
					return odgovor;
				}
				odgovor = "OK ALARM";
				meteo[2] = podjela[3];
				if (meteo.length >= 4) {
					meteo[3] = podjela[4];
				}
				if (meteo.length == 5) {
					meteo[4] = podjela[5];
				}

				prekidVrijeme = false;
				zaUpis = meteo;
				break;
			} else {
				prekidVrijeme = true;
			}
		}

		if (prekidVrijeme) {
			odgovor = "ERROR 29: Nije upisano točno vrijeme podatka.";
			return odgovor;
		}

		for (String[] meteo : listaMeteo) {
			if (podjela[1].equals(meteo[0])) {
				String[] alarm = new String[meteo.length];
				if (meteo.length != brojArgumenata) {
					odgovor = "ERROR 29: Unesen pogrešan broj argumenata. Senzor prima " + (meteo.length - 1)
							+ " argumenta.";
					break;
				} else {
					int vrijeme3 = pretvorbaVremena((meteo[1]).trim());
					int vrijeme4 = pretvorbaVremena((podjela[2]).trim());
					if (vrijeme3 <= vrijeme4) {
						odgovor = "OK";
						alarm[0] = meteo[0];
						alarm[1] = meteo[1];
						temperatura = Float.parseFloat(meteo[2]);
						if (Math.abs(temperatura - Float.parseFloat(podjela[3])) > odstupanjeTemp) {
							odgovor += " TEMP";
							alarm[2] = "TEMP";
							upaliAlarm = true;

						}

						if (meteo.length >= 4) {
							vlaga = Float.parseFloat(meteo[3]);
							if (Math.abs(vlaga - Float.parseFloat(podjela[4])) > odstupanjVlaga) {
								odgovor += " VLAGA";
								alarm[3] = "VLAGA";
								upaliAlarm = true;

							}
						}

						if (meteo.length == 5) {
							tlak = Float.parseFloat(meteo[4]);
							if (Math.abs(tlak - Float.parseFloat(podjela[5])) > odstupanjeTlak) {
								odgovor += " TLAK";
								alarm[4] = "TLAK";
								upaliAlarm = true;

							}
						}
						if (upaliAlarm) {
							listaAlarm.add(alarm);
							listaObrisati.add(meteo);
						}
					}
				}
			}
		}
		obrisiMeteo(zaUpis);
		return odgovor;
	}

	/**
	 * Obrisi meteo.
	 *
	 * @param zaUpis zapis tipa MeteoSimulacija kojeg želimo obrisati
	 */
	private void obrisiMeteo(String[] zaUpis) {
		listaMeteo.removeAll(listaObrisati);
		listaMeteo.add(zaUpis);
		listaAlarm.remove(listaAlarm.size() - 1);
	}

	/**
	 * Dohvati maksimalnu vrijednost nekog mjernog podatka za traženi uređeaj
	 *
	 * @param podjela predmetni dio poruke
	 * @param ind     indeks označava traženu varijablu (temperaturu, vlagu ili
	 *                tlak)
	 * @return vraća odgovor na upit na temelju stanja posljednjeg uređaja prije
	 *         zadanog
	 */
	private String dohvatiMaks(String[] podjela, int ind) {
		int indeks = ind;

		if (ind == 2) {
			indeks = ind;
		}
		if (ind == 3) {
			indeks = ind;
		}
		if (ind == 4) {
			indeks = ind;
		}

		String odgovor = "ERROR 29: Uređaj postoji ali za njega ne postoje podaci.";
		float varijabla = 0;
		int alarm_vrijeme = 0;
		for (String[] alarm : listaAlarm) {
			if (alarm[0].equals(podjela[2])) {
				if (alarm_vrijeme > pretvorbaVremena((alarm[1]).trim())) {
					break;
				} else {
					alarm_vrijeme = pretvorbaVremena((alarm[1]).trim());
				}
			}
		}

		for (String[] meteo : listaMeteo) {
			if (indeks - 1 >= meteo.length) {
				odgovor = "ERROR 29: Senzor ne sadrži sve tražene podatke.";
				break;
			}

			if (meteo[0].equals(podjela[2]) && pretvorbaVremena((meteo[1]).trim()) >= alarm_vrijeme) {
				float vrijednost = Float.parseFloat(meteo[indeks]);
				if (vrijednost > varijabla) {
					varijabla = vrijednost;
					odgovor = "OK";
					odgovor += " " + meteo[1] + " " + varijabla;
				}
			}
		}
		return odgovor;
	}

	/**
	 * Trazi senzor.
	 *
	 * @param senzorID ID senzora
	 * @return vraća odgovor "OK" ako senzor postoji skupa s najnovijim podacima o
	 *         serveru
	 */
	private String traziSenzor(String senzorID) {
		String odgovor = "ERROR 29: Uređaj postoji ali za njega ne postoje podaci.";
		int vrijeme = 0;
		for (String[] meteo : listaMeteo) {
			if (meteo[0].equals(senzorID)) {
				if (vrijeme > pretvorbaVremena(meteo[1])) {
					break;
				} else {
					odgovor = "OK";
					vrijeme = pretvorbaVremena(meteo[1]);
					for (int i = 0; i < meteo.length; i++) {
						odgovor += " " + meteo[i];
					}
				}
			}
		}
		return odgovor;

	}

	/**
	 * Pretvorba vremena - metoda za pretvorbu vremena u integer oblik za lakšu
	 * usporedbu
	 *
	 * @param meteo zapis mjerenja
	 * @return vrijeme mjerenja izraženo u milisekundama
	 */
	private int pretvorbaVremena(String meteo) {
		String[] vrijeme = meteo.split(":");
		int rezultat = Integer.parseInt(vrijeme[0]) * 3600 + Integer.parseInt(vrijeme[1]) * 60
				+ Integer.parseInt(vrijeme[2]);
		return rezultat;
	}

	/**
	 * Pohrani meteo metoda radi prihvat zapisa koje šalje SimulatorMeteo.
	 *
	 * @param meteo zapis mjerenje
	 */
	private void pohraniMeteo(String meteo) {
		String[] poljeMeteo = meteo.split(" ");
		listaMeteo.add(poljeMeteo);
	}

	/**
	 * Provjera ID - provjerava postojanje traženog uređaja
	 *
	 * @param predmet ID uređaj kojeg provjeravamo
	 * @return odgovor na upit, ako uređaj postoji onda "DA"
	 */
	private String provjeraID(String predmet) {
		String odgovor = "ERROR 23: uređaj ne postoji.";
		for (Entry<String, Uredaj> uredaj : gp.uredaji.entrySet()) {
			String idUredaja = uredaj.getValue().id();
			if (predmet.equals(idUredaja)) {
				odgovor = "OK";
				break;
			}
		}
		return odgovor;
	}

	/**
	 * Autentikacija korisnika čitanjem informacija o njemu s autentikacijskog
	 * dijela naredbe.
	 *
	 * @param autent autentikacijski dio naredbe
	 * @return odgovor na autentikaciju - postoji, ne postoji, nije administrator
	 */
	public String autentikacija(String autent) {
		int kodGreske = 25;
		String odgovor = "";
		String[] podjela = autent.split(" ");
		String kIme = podjela[0];
		String loz = podjela[1];

		for (Entry<String, Korisnik> korisnik : gp.korisnici.entrySet()) {
			String korisnickoIme = korisnik.getValue().korisnickoIme();
			String lozinka = korisnik.getValue().lozinka();
			boolean administrator = korisnik.getValue().administrator();

			if (korisnickoIme.equals(kIme) && lozinka.equals(loz)) {
				if (administrator == true) {
					kodGreske = 0;
					break;
				} else {
					kodGreske = 22;
					break;
				}
			} else {
				kodGreske = 21;
			}
		}

		switch (kodGreske) {
		case 21: {
			odgovor = "ERROR 21: Korisnik ne postoji ili je pogrešna lozinka.";
			break;
		}
		case 22: {
			odgovor = "ERROR 22: Korisnik nije administrator.";
			break;
		}
		case 0:
			odgovor = "OK";
			break;
		}
		return odgovor;
	}

	/**
	 * Interrupt metoda dretve
	 */
	@Override
	public void interrupt() {
		super.interrupt();
	}

}
//java -cp target/dkusic_zadaca_1_app-1.0.0.jar org.foi.nwtis.dkusic.zadaca_1.GlavniKlijent -k pkos -l 123456 -a localhost -v 8000 -t 0 --kraj