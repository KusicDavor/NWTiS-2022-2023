package org.foi.nwtis.dkusic.zadaca_1;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Klasa TestOpcijaGlavniKlijent sadrži REGEX uzorke kojima se provjerava ispravnost unesena naredbe u klasi Glavni klijent.
 */
public class TestOpcijaGlavniKlijent {

	/**
	 * Main.
	 *
	 * @param args argumenti komandne linije
	 * @return true, ako je naredba sintaksno ispravna
	 */

	public static boolean main(String[] args) {

		boolean status = false;

		// -k korisnik -l lozinka -a (ipadresa | adresa) -v mreznaVrata -t cekanje
		// ((--meteo idUredaj) |
		// --kraj)
		// -k pero -l 123456 -s localhost -p 8000 -t 0 --meteo FOI1-BME280
		// -k pero -l 123456 -s localhost -p 8000 -t 0 --kraj

		// koristi indeksirane grupe (...) poklapanja
		String sintaksa1 = "-k ([\\w-]{3,10}) -l ([\\w#!-]{3,10}) -a ([\\w.-]+) -v (8[0-9]{3}|9[0-9]{3}) -t ([0-9]+) --kraj";

		// koristi imenovane grupe (?<ime>...) poklapanja
		String sintaksa2 = "-k (?<korisnik>[\\w]{3,10}) -l (?<lozinka>[\\w-]{3,10}) -a (?<adresa>[\\w\\-\\[.\\]]+) -v (?<mreznaVrata>8[0-9]{3}|9[0-9]{3}) -t (?<cekanje>[0-9]+)(( --meteo (?<meteo>[\\w-]+))| --makstemp (?<makstemp>[\\w-]+)| --maksvlaga (?<maksvlaga>[\\w-]+)| --makstlak (?<makstlak>[\\w-]+)| --alarm (?<alarm>'[\\w\\s]+')| --udaljenost (?<udaljenost>'[\\w\\s]+' '[\\w\\s]+'|spremi)| (?<kraj>--kraj))$";
		String sintaksa3 = "KORISNIK (?<korisnik>[\\w]{3,10}) LOZINKA (?<lozinka>[\\w-]{3,10})( METEO (?<meteo>[\\w-]+)| MAKS (?<maks>(TEMP|VLAGA|TLAK) [\\w-]+)| ALARM (?<alarm>'[\\w\\s]+')| UDALJENOST (?<udaljenost>'[\\w\\s]+' '[\\w\\s]+')|SPREMI)| (?<kraj>KRAJ)";
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < args.length; i++) {
			sb.append(args[i]).append(" ");
		}
		String s = sb.toString().trim();

		Pattern pattern1 = Pattern.compile(sintaksa1);
		Matcher m1 = pattern1.matcher(s);
		boolean status1 = m1.matches();
		if (status1) {
			status = true;
		}

		Pattern pattern2 = Pattern.compile(sintaksa2);
		Matcher m2 = pattern2.matcher(s);
		boolean status2 = m2.matches();
		if (status2) {
			status = true;
		}
		
		Pattern pattern3 = Pattern.compile(sintaksa3);
		Matcher m3 = pattern3.matcher(s);
		boolean status3 = m3.matches();
		if (status3) {
			status = true;
		}
		return status;
	}
}
