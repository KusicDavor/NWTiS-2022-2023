package org.foi.nwtis.dkusic.zadaca_1;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.foi.nwtis.dkusic.zadaca_1.podaci.Uredaj;
import org.foi.nwtis.dkusic.zadaca_1.podaci.UredajVrsta;

/**
 * Intancira klasu CitanjeUredaja koja služi za učitavanje uređaja i spremanje
 * na glavni poslužitelj.
 */
public class CitanjeUredaja {

	/**
	 * Ucitaj datoteku.
	 *
	 * @param nazivDatoteke naziv datoteke koja sadrži podatke o uređajima
	 * @return map koji sadrži sve uređaje
	 * @throws IOException Ako je čitanje bilo neuspješno.
	 */
	public Map<String, Uredaj> ucitajDatoteku(String nazivDatoteke) throws IOException {
		var putanja = Path.of(nazivDatoteke);
		if (!Files.exists(putanja) || Files.isDirectory(putanja) || !Files.isReadable(putanja)) {
			throw new IOException("Datoteka '" + nazivDatoteke + "' nije datoteka ili nije moguće čitati.");
		}
		var uredaji = new HashMap<String, Uredaj>();
		var citac = Files.newBufferedReader(putanja, Charset.forName("UTF-8"));

		while (true) {
			var redak = citac.readLine();
			if (redak == null) {
				break;
			}
			var odsjek = redak.split(";");
			if (odsjek.length != 4) {
				Logger.getGlobal().log(Level.WARNING, "ERROR 29: Greška u datoteci s podacima uređaja.");
			} else {
				UredajVrsta vrsta = UredajVrsta.odBroja(Integer.parseInt(odsjek[3]));
				var uredaj = new Uredaj(odsjek[0], odsjek[1], odsjek[2], vrsta);
				uredaji.put(odsjek[1], uredaj);
			}
		}
		return uredaji;
	}
}
