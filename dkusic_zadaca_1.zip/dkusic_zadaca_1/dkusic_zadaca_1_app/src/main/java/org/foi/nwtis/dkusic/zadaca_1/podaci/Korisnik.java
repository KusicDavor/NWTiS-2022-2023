package org.foi.nwtis.dkusic.zadaca_1.podaci;

/**
 *  zapis Korisnik služi za kreiranje objekta koji predstavlja korisnika
 */
public record Korisnik(String prezime, String ime, String korisnickoIme, String
		lozinka, boolean administrator) {
}
