package org.foi.nwtis.dkusic.zadaca_1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.foi.nwtis.Konfiguracija;
import org.foi.nwtis.KonfiguracijaApstraktna;
import org.foi.nwtis.NeispravnaKonfiguracija;
import org.foi.nwtis.dkusic.zadaca_1.podaci.MeteoSimulacija;

// TODO: Auto-generated Javadoc
/**
 * The Class SimulatorMeteo.
 */
public class SimulatorMeteo {
	
	/** konfiguracija klase SimulatorMeteo */
	protected Konfiguracija konfiguracija;
	
	/** varijabla za provjeru ako potrebno prekinuti komunikaciju sa poslužiteljem */
	private String provjera = "";
	
	/** varijabla za brojanje pokušaja slanja podataka */
	private int brojac = 0;
	
	/** varijabla za provjeru ako potrebno prekinuti komunikaciju sa poslužiteljem */
	private int prekid = 5;

	/**
	 * Glavna metoda za rad sa podacima simulacije.
	 *
	 * @param args naziv datoteke konfiguracije
	 * @throws InterruptedException baca pogrešku ako je došlo do prekida
	 * @throws IOException baca pogrešku ako je došlo greške u komunikaciji
	 */
	public static void main(String[] args) throws InterruptedException, IOException {
		var simulatorMeteo = new SimulatorMeteo();
		if (!simulatorMeteo.provjeriArgumente(args)) {
			Logger.getGlobal().log(Level.WARNING, "ERROR: Nije upisan naziv datoteke.");
			return;
		}
		try {
			simulatorMeteo.konfiguracija = simulatorMeteo.ucitajPostavke(args[0]);
			if (provjeraDatoteke(simulatorMeteo.konfiguracija.dajPostavku("datotekaMeteo"))) {
				Thread slanjePodataka = new Thread(() -> {
					try {
						simulatorMeteo.pokreniSimulatora(simulatorMeteo);
					} catch (Exception e) {
						Logger.getLogger(SimulatorMeteo.class.getName()).log(Level.WARNING,
								"ERROR: Pogreška pri slanju podataka. ");
					}
				});
				slanjePodataka.start();
				while (true) {
					Scanner sc = new Scanner(System.in);
					String komanda = sc.nextLine();
					String[] poljeArgumenata = komanda.split(" ");
					boolean ispravni = TestOpcijaSimulator.main(poljeArgumenata);
					if (!ispravni) {
						Logger.getLogger(SimulatorMeteo.class.getName()).log(Level.WARNING,
								"ERROR 20: Format komande nije ispravan.");
					} else {
						spajanjeNaPosluzitelj(simulatorMeteo, komanda);
					}
				}
			}
		} catch (NeispravnaKonfiguracija e) {
			Logger.getGlobal().log(Level.WARNING, "ERROR: Pogreška kod datoteke postavki. " + e.getMessage());
		} catch (IOException e) {
			Logger.getGlobal().log(Level.WARNING, "ERROR 29: Poslužitelj ne reagira. " + e.getMessage());
		}
	}

	/**
	 * Pokreće spajanje i čitanje odgovora PosluziteljUdaljenost .
	 *
	 * @param simulatorMeteo za pokretanje socketa kojim će dretva komunicirati s drugim poslužiteljima
	 * @throws IOException baca pogrešku ako je došlo greške u komunikaciji
	 * @throws InterruptedException baca pogrešku ako je došlo do prekida
	 * @throws NeispravnaKonfiguracija baca pogrešku ako je neispravna konfiguracija
	 */
	private void pokreniSimulatora(SimulatorMeteo simulatorMeteo)
			throws IOException, InterruptedException, NeispravnaKonfiguracija {
		int ispis = Integer.parseInt(this.konfiguracija.dajPostavku("ispis"));
		var nazivDatoteke = this.konfiguracija.dajPostavku("datotekaMeteo");
		var putanja = Path.of(nazivDatoteke);
		if (!Files.exists(putanja) || Files.isDirectory(putanja) || !Files.isReadable(putanja)) {
			throw new IOException("Datoteka '" + nazivDatoteke + "' nije datoteka ili nije moguće čitati.");
		}
		var citac = Files.newBufferedReader(putanja, Charset.forName("UTF-8"));
		int rbroj = 0;
		MeteoSimulacija prethodniMeteo = null;
		while (true) {
			var redak = citac.readLine();
			if (provjera.contains("ERROR 21")) {
				break;
			}
			if (redak == null) {
				break;
			}
			rbroj++;
			if (rbroj == 1) {
				continue;
			}
			var odsjek = redak.split(";");
			if (odsjek.length != 5) {
				Logger.getGlobal().log(Level.INFO, redak);
			} else {

				if (provjera.contains("ERROR 22")) {
					break;
				}

				var vazeciMeteo = new MeteoSimulacija(odsjek[0], odsjek[1], Float.parseFloat(odsjek[2]),
						Float.parseFloat(odsjek[3]), Float.parseFloat(odsjek[4]));

				if (ispis == 1) {
					Logger.getGlobal().log(Level.INFO, vazeciMeteo.toString());
				}
				if (rbroj == 2) {
					this.posaljiMeteoPodatke(vazeciMeteo, simulatorMeteo);
					prethodniMeteo = vazeciMeteo;
				} else {
					if (this.izracunajOdradiSpavanje(prethodniMeteo, vazeciMeteo, ispis)) {
						this.posaljiMeteoPodatke(vazeciMeteo, simulatorMeteo);
					}
					prethodniMeteo = vazeciMeteo;
				}
			}
		}
	}

	/**
	 * Provjerava broj unesenih argumenata, ako je unesen argument datoteke konfiguracije
	 *
	 * @param args naziv datoteke konfiguracije
	 * @return true, ako postoji jedan argument, inače false
	 */
	boolean provjeriArgumente(String[] args) {
		return args.length == 1 ? true : false;
	}

	/**
	 * Izracunaj odradi spavanje.
	 *
	 * @param prethodniMeteo the prethodni meteo
	 * @param vazeciMeteo the vazeci meteo
	 * @param ispis the ispis
	 * @return true, if successful
	 * @throws InterruptedException baca grešku ako je došlo do prekida
	 */
	private boolean izracunajOdradiSpavanje(MeteoSimulacija prethodniMeteo, MeteoSimulacija vazeciMeteo, int ispis)
			throws InterruptedException {
		int trajanjeSekunde = Integer.parseInt(konfiguracija.dajPostavku("trajanjeSekunde"));
		String[] prvi = prethodniMeteo.vrijeme().split(":");
		String[] drugi = vazeciMeteo.vrijeme().split(":");
		int prvoVrijemeSek = Integer.parseInt(prvi[0]) * 3600 + Integer.parseInt(prvi[1]) * 60
				+ Integer.parseInt(prvi[2]);
		int drugoVrijemeSek = Integer.parseInt(drugi[0]) * 3600 + Integer.parseInt(drugi[1]) * 60
				+ Integer.parseInt(drugi[2]);
		int razlikaSek = drugoVrijemeSek - prvoVrijemeSek;
		if (razlikaSek >= 0) {
			Thread.sleep(razlikaSek * 1000 / trajanjeSekunde);
		} else {
			if (ispis == 1) {
				Logger.getGlobal().log(Level.WARNING,
						"ERROR 29: Vrijeme očitanja je starije od posljednjeg podatka. Očitanje je preskočeno. "
								+ vazeciMeteo.id() + " " + vazeciMeteo.vrijeme());
			}
			return false;
		}
		return true;
	}

	/**
	 * Šalje podatke iz datoteke s podacima o mjerenjima
	 *
	 * @param meteo          jedno mjerenje
	 * @param simulatorMeteo ova klasa SimulatorMeteo
	 * @throws IOException baca pogrešku u radu s komunikacijij
	 */
	private void posaljiMeteoPodatke(MeteoSimulacija meteo, SimulatorMeteo simulatorMeteo) throws IOException {
		int ispis = Integer.parseInt(this.konfiguracija.dajPostavku("ispis"));
		String datotekaProblema = simulatorMeteo.konfiguracija.dajPostavku("datotekaProblema");
		int brojPokusaja = Integer.parseInt(this.konfiguracija.dajPostavku("brojPokusaja"));
		String kIme = simulatorMeteo.konfiguracija.dajPostavku("korisnickoIme");
		String lozinka = simulatorMeteo.konfiguracija.dajPostavku("korisnickaLozinka");
		String autent = "KORISNIK" + " " + kIme + " " + "LOZINKA" + " " + lozinka + " ";
		String adresa = simulatorMeteo.konfiguracija.dajPostavku("posluziteljGlavniAdresa");
		int mreznaVrata = Integer.parseInt(simulatorMeteo.konfiguracija.dajPostavku("posluziteljGlavniVrata"));
		int maksCekanje = Integer.parseInt(simulatorMeteo.konfiguracija.dajPostavku("maksCekanje"));
		StringBuilder poruka = new StringBuilder();
		for (brojac = 0; brojac < brojPokusaja; brojac++) {
			try (var mreznaUticnica = new Socket()) {
				InetSocketAddress socketAdress = new InetSocketAddress(adresa, mreznaVrata);
				mreznaUticnica.connect(socketAdress, maksCekanje);
				var citac = new BufferedReader(
						new InputStreamReader(mreznaUticnica.getInputStream(), Charset.forName("UTF-8")));
				var pisac = new BufferedWriter(
						new OutputStreamWriter(mreznaUticnica.getOutputStream(), Charset.forName("UTF-8")));
				String komanda = obradiMeteo(meteo);
				pisac.write(autent + komanda);
				pisac.flush();
				mreznaUticnica.shutdownOutput();
				while (true) {
					var redak = citac.readLine();
					if (redak == null) {
						break;
					}
					if (ispis == 1) {
						Logger.getGlobal().log(Level.SEVERE, redak + " ------ broj pokušaja slanja: " + (brojac + 1));
					}
					poruka.append(redak);
					provjera = poruka.toString();

					mreznaUticnica.shutdownInput();
					mreznaUticnica.close();
					prekid = provjera.compareTo("OK");

					if (brojac == brojPokusaja - 1) {
						try (FileWriter writer = new FileWriter(datotekaProblema, StandardCharsets.UTF_8, true)) {
							writer.write(meteo.id() + ";" + meteo.vrijeme() + ";" + meteo.temperatura() + ";"
									+ meteo.vlaga() + ";" + meteo.tlak() + ";" + redak + "\n");
						} catch (IOException e) {
							Logger.getGlobal().log(Level.WARNING,
									"ERROR: Pogreška kod upisa u datoteku problema. " + e.getMessage());
						}
					}
				}
				if (prekid == 0 || provjera.contains("ERROR 21") || provjera.contains("POHRANJEN")
						|| provjera.contains("ERROR 22")) {
					break;
				}
			}
		}
	}

	/**
	 * metoda za obradu podataka očitanja
	 *
	 * @param meteo jedno očitanje
	 * @return vraća sve podatke tog očitanja
	 */
	private String obradiMeteo(MeteoSimulacija meteo) {
		String odgovor = meteo.id() + " ";
		if (!meteo.vrijeme().equals("-999")) {
			odgovor += meteo.vrijeme() + " ";
		}
		if (meteo.temperatura() != -999) {
			odgovor += meteo.temperatura() + " ";
		}
		if (meteo.vlaga() != -999) {
			odgovor += meteo.vlaga() + " ";
		}
		if (meteo.tlak() != -999) {
			odgovor += meteo.tlak();
		}
		return odgovor;
	}

	/**
	 * Učitaj postavke.
	 *
	 * @param nazivDatoteke Naziv datoteke
	 * @return vraća datoteku konfiguracije
	 * @throws NeispravnaKonfiguracija baca pogrešku ako nije ispravna konfiguracija
	 */
	Konfiguracija ucitajPostavke(String nazivDatoteke) throws NeispravnaKonfiguracija {
		return KonfiguracijaApstraktna.preuzmiKonfiguraciju(nazivDatoteke);
	}

	/**
	 * Provjera postojanja datoteke sa podacima o mjerenjima.
	 *
	 * @param datoteka naziv datoteke s podacima
	 * @return vraća true ako postoji
	 * @throws NeispravnaKonfiguracija baca pogrešku ako nije ispravna konfiguracija
	 */
	public static boolean provjeraDatoteke(String datoteka) throws NeispravnaKonfiguracija {
		File file = new File(datoteka);
		if (!file.exists()) {
			throw new NeispravnaKonfiguracija("Nema datoteke s podacima.");
		}
		return true;
	}

	/**
	 * Spajanje na GlavniPosluzitelj i slanje naredbe.
	 *
	 * @param simulatorMeteo jedno očitanje
	 * @param komanda korisnikova naredba
	 * @throws IOException baca pogrešku ako nije ispravna konfiguracija
	 */
	private static void spajanjeNaPosluzitelj(SimulatorMeteo simulatorMeteo, String komanda) throws IOException {
		String adresa = simulatorMeteo.konfiguracija.dajPostavku("posluziteljGlavniAdresa");
		int mreznaVrata = Integer.parseInt(simulatorMeteo.konfiguracija.dajPostavku("posluziteljGlavniVrata"));
		int maksCekanje = Integer.parseInt(simulatorMeteo.konfiguracija.dajPostavku("maksCekanje"));
		StringBuilder poruka = new StringBuilder();
		try (var mreznaUticnica = new Socket()) {
			InetSocketAddress socketAdress = new InetSocketAddress(adresa, mreznaVrata);
			mreznaUticnica.connect(socketAdress, maksCekanje);
			var citac = new BufferedReader(
					new InputStreamReader(mreznaUticnica.getInputStream(), Charset.forName("UTF-8")));
			var pisac = new BufferedWriter(
					new OutputStreamWriter(mreznaUticnica.getOutputStream(), Charset.forName("UTF-8")));
			pisac.write(komanda);
			pisac.flush();
			mreznaUticnica.shutdownOutput();
			while (true) {
				var redak = citac.readLine();
				if (redak == null) {
					break;
				}
				Logger.getGlobal().log(Level.INFO, redak);
				poruka.append(redak);
				mreznaUticnica.shutdownInput();
				mreznaUticnica.close();
			}
		}
	}
}
//java -cp target/dkusic_zadaca_1_app-1.0.0.jar org.foi.nwtis.dkusic.zadaca_1.SimulatorMeteo NWTiS_dkusic_1.txt