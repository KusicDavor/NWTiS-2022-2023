package org.foi.nwtis.dkusic.zadaca_1;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

// TODO: Auto-generated Javadoc
/**
 * Za testiranje sintakse naredbi u SimulatorMeteo klasi.
 */
public class TestOpcijaSimulator {

	/**
	 * Glavna metoda koja obrađuje sintaksu naredbe.
	 *
	 * @param args argumenti komandne linije
	 * @return true, ako je naredba sinktaksno ispravna
	 */

	public static boolean main(String[] args) {

		// KORISNIK pero LOZINKA 123456 SENZOR FOISK-SHTC3 0:0:18 19 16
		// KORISNIK pero LOZINKA 123456 SENZOR FOI1-BME280 0:0:20 6.3 54.9 1006.5
		// KORISNIK pero LOZINKA 123456 SENZOR FOIKŽ-DHT11 0:0:20 6.8

		// koristi imenovane grupe (?<ime>...) poklapanja
		String sintaksa ="KORISNIK (?<korisnik>[\\w]{3,10}) LOZINKA (?<lozinka>[\\w-]{3,10}) SENZOR (?<idUredaj>[\\w-]+) (?<vrijeme>([1-9]|1[0-9]|2[0-3]|0):([0-9]|[1-5][0-9]):([0-9]|[1-5][0-9])) (?<temperatura>-?\\d{1,4}(\\.\\d)?)( (?<vlaga>\\d{1,4}(\\.\\d)?))?( (?<tlak>\\d{1,4}(\\.\\d)?))?";
 
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < args.length; i++) {	
			sb.append(args[i]).append(" ");
		}
		
		String s = sb.toString().trim();
		Pattern pattern = Pattern.compile(sintaksa);
		Matcher m = pattern.matcher(s);
		boolean status = m.matches();
		
		return status;
	}
}
