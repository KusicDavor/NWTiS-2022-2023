package org.foi.nwtis.dkusic.zadaca_1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.foi.nwtis.Konfiguracija;
import org.foi.nwtis.KonfiguracijaApstraktna;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

/**
 * Klasa GlavniPosluziteljTest služi za testiranje rada metoda klase GlavniPoslužitelj, validira unos podataka i argumenata.
 */
class GlavniPosluziteljTest {

	/** Konfiguracija potrebna za instanciranje klase GlavniPosluzitelj. */
	static Konfiguracija konf;
	
	/** Instanca klase GlavniPosluzitelj */
	GlavniPosluzitelj gp = new GlavniPosluzitelj(konf);
	
	/**
	 * Metoda za postavljanje prije početka testiranja, konstruktor
	 *
	 * @throws Exception baca pogrešku ako je postavljanje konfiguracije bilo neuspješno
	 */
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		konf = KonfiguracijaApstraktna.preuzmiKonfiguraciju("NWTiS_dkusic_3.txt");
	}

	/**
	 * Metoda za čišćenje nakon provedenih svih testiranja.
	 *
	 * @throws Exception baca pogrešku ako je čišćenje bilo neuspješno
	 */
	@AfterAll
	static void tearDownAfterClass() throws Exception {
		konf = null;
	}

	/**
	 * Metoda za postavljanje uvjeta i varijabla prije izvođenja svakog pojedinačnog jediničnog testa.
	 *
	 * @throws Exception baca pogrešku ako je postavljanje bilo neuspješno
	 */
	@BeforeEach
	void setUp() throws Exception {
	}

	/**
	 * Metoda za dekonstrukciju koja se izvodi nakon svakog testa.
	 *
	 * @throws Exception baca pogrešku ako je postavljanje bilo neuspješno
	 */
	@AfterEach
	void tearDown() throws Exception {
		this.gp = null;
	}

	/**
	 * Testira pokretanje poslužitelja.
	 */
	@Disabled("Još nije implementiran test")
	@Test
	void testPokreniPosluzitelj() {
		fail("Not yet implemented");
	}
	

	/**
	 * Testira ucitavanje korisnika.
	 */
	@Test
	void testUcitajKorisnike() {
		try {
			gp.ucitajKorisnike();
			assertEquals(10, gp.korisnici.size());
			assertEquals("Pero", gp.korisnici.get("pkos").ime());
			assertEquals("Kos", gp.korisnici.get("pkos").prezime());
			assertEquals(true, gp.korisnici.get("pkos").administrator());
			assertNull(gp.korisnici.get("dkusic"));
		} catch (IOException e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * Testira različite situacije otvaranja mrežnih vrata.
	 */
	@Disabled("Još nije implementiran test")
	@Test
	void testOtvoriMreznaVrata() {
		fail("Not yet implemented");
	}

}
