package org.foi.nwtis.dkusic.zadaca_3.ws;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.PostavkeBazaPodataka;
import org.foi.nwtis.dkusic.zadaca_3.jpa.Airports;
import org.foi.nwtis.dkusic.zadaca_3.zrna.AirportFacade;
import org.foi.nwtis.dkusic.zadaca_3.zrna.Slusac;
import org.foi.nwtis.podaci.Aerodrom;
import org.foi.nwtis.podaci.Lokacija;
import org.foi.nwtis.podaci.UdaljenostKlasa;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

@WebService(serviceName = "aerodromi")
public class WsAerodromi {
  @Resource(lookup = "java:app/jdbc/nwtis_bp")
  javax.sql.DataSource ds;

  public static PostavkeBazaPodataka konfig = Slusac.getkonfDB();

  @Inject
  AirportFacade airportFacade;

  @WebMethod
  public List<Aerodrom> dajSveAerodrome(@WebParam int odBroja, @WebParam int broj) {
    List<Aerodrom> listaAerodroma = new ArrayList<Aerodrom>();
    var aerodromi = airportFacade.findAll(odBroja, broj);
    for (Airports airports : aerodromi) {
      String[] lok = airports.getCoordinates().split(",");
      Lokacija lokacija = new Lokacija();
      lokacija.postavi(lok[0], lok[1]);
      Aerodrom ad =
          new Aerodrom(airports.getIcao(), airports.getName(), airports.getIsoCountry(), lokacija);
      listaAerodroma.add(ad);
    }
    return listaAerodroma;
  }

  @WebMethod
  public Aerodrom dajAerodromJpa(@WebParam String icao) {
    Aerodrom aerodrom = null;
    if (icao == null || icao.trim().length() == 0) {
      return aerodrom;
    }
    Airports a = airportFacade.find(icao);
    var koord = a.getCoordinates().split(",");
    var lokacija = new Lokacija(koord[1], koord[0]);
    aerodrom = new Aerodrom(a.getIcao(), a.getName(), a.getIsoCountry(), lokacija);
    return aerodrom;
  }

  @WebMethod
  public List<UdaljenostKlasa> dajUdaljenostiAerodroma(@WebParam String icaoOd,
      @WebParam String icaoDo) {

    List<UdaljenostKlasa> lista = new ArrayList<UdaljenostKlasa>();
    PreparedStatement pstmt = null;

    String query =
        "select ICAO_FROM, ICAO_TO, COUNTRY, DIST_CTRY from AIRPORTS_DISTANCE_MATRIX WHERE "
            + "ICAO_FROM = ? AND ICAO_TO = ?";

    try (var con = ds.getConnection()) {

      pstmt = con.prepareStatement(query);
      pstmt.setString(1, icaoOd);
      pstmt.setString(2, icaoDo);

      ResultSet rs = pstmt.executeQuery();

      while (rs.next()) {
        String drzava = rs.getString("COUNTRY");
        float udaljDrzava = rs.getFloat("DIST_CTRY");
        UdaljenostKlasa udaljenost = new UdaljenostKlasa(drzava, udaljDrzava);
        lista.add(udaljenost);

      }
      rs.close();
      pstmt.close();
      con.close();
    } catch (Exception e) {
      Logger.getGlobal().log(Level.SEVERE, e.getMessage());
      System.out.println(e.getMessage());
    } finally {
      try {
        if (pstmt != null && !pstmt.isClosed()) {
          pstmt.close();
        }
      } catch (SQLException e) {
        Logger.getGlobal().log(Level.SEVERE, e.getMessage());
        System.out.println(e.getMessage());
      }
    }
    return lista;
  }


  @WebMethod
  public List<UdaljenostKlasa> dajSveUdaljenostiAerodroma(@WebParam String icao,
      @WebParam int odBroja, @WebParam int broj) {

    List<UdaljenostKlasa> listaUdaljenosti = new ArrayList<UdaljenostKlasa>();
    PreparedStatement pstmt = null;

    String query =
        "SELECT * FROM AIRPORTS_DISTANCE_MATRIX adm WHERE adm.ICAO_FROM = ? LIMIT ? OFFSET ?;";
    try (var con = ds.getConnection()) {

      pstmt = con.prepareStatement(query);
      pstmt.setString(1, icao);
      pstmt.setInt(2, broj);
      pstmt.setInt(3, odBroja);

      ResultSet rs = pstmt.executeQuery();

      while (rs.next()) {
        String drzava = rs.getString("COUNTRY");
        float km = rs.getFloat("DIST_TOT");

        UdaljenostKlasa udaljenosti = new UdaljenostKlasa(drzava, km);
        listaUdaljenosti.add(udaljenosti);
      }

      rs.close();
      pstmt.close();
      con.close();
    } catch (Exception e) {
      Logger.getGlobal().log(Level.SEVERE, e.getMessage());
      System.out.println(e.getMessage());
    } finally {
      try {
        if (pstmt != null && !pstmt.isClosed()) {
          pstmt.close();
        }
      } catch (SQLException e) {
        Logger.getGlobal().log(Level.SEVERE, e.getMessage());
        System.out.println(e.getMessage());
      }
    }
    return listaUdaljenosti;
  }

  public UdaljenostKlasa dajNajduljiPutDrzave(@WebParam String icao) {
    PreparedStatement pstmt = null;
    UdaljenostKlasa rezultat = null;

    String query = "SELECT * FROM AIRPORTS_DISTANCE_MATRIX adm WHERE adm.ICAO_FROM  = ?;";
    try (var con = ds.getConnection()) {

      pstmt = con.prepareStatement(query);
      pstmt.setString(1, icao);

      ResultSet rs = pstmt.executeQuery();
      float najveca_udaljenost = 0;
      String drzava = "";

      while (rs.next()) {
        float udaljenost = rs.getFloat("DIST_CTRY");
        if (udaljenost > najveca_udaljenost) {
          najveca_udaljenost = udaljenost;
          drzava = rs.getString("COUNTRY");
        }

        rezultat = new UdaljenostKlasa(drzava, najveca_udaljenost);
      }

      rs.close();
      pstmt.close();
      con.close();
    } catch (Exception e) {
      Logger.getGlobal().log(Level.SEVERE, e.getMessage());
      System.out.println(e.getMessage());
    } finally {
      try {
        if (pstmt != null && !pstmt.isClosed()) {
          pstmt.close();
        }
      } catch (SQLException e) {
        Logger.getGlobal().log(Level.SEVERE, e.getMessage());
        System.out.println(e.getMessage());
      }
    }

    return rezultat;
  }
}
