package org.foi.nwtis.dkusic.zadaca_3.zrna;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import org.foi.nwtis.PostavkeBazaPodataka;
import org.foi.nwtis.rest.klijenti.NwtisRestIznimka;
import org.foi.nwtis.rest.klijenti.OSKlijent;
import org.foi.nwtis.rest.podaci.LetAviona;
import jakarta.inject.Inject;

public class SakupljacLetovaAviona extends Thread {

  @Inject
  JmsPosiljatelj jmsPosiljatelj;

  public static PostavkeBazaPodataka konfig;
  private DataSource ds;
  private static int broj;

  @Override
  public synchronized void start() {
    konfig = Slusac.getkonfDB();
    InitialContext ctx;
    try {
      ctx = new InitialContext();
      ds = (DataSource) ctx.lookup("java:app/jdbc/nwtis_bp");

    } catch (Exception e) {
      e.printStackTrace();
    }
    super.start();
  }

  @Override
  public synchronized void run() {
    jmsPosiljatelj = new JmsPosiljatelj();
    long oznakaPocetka = System.currentTimeMillis() / 1000;
    long trajanjeCiklusa = Integer.parseInt(konfig.dajPostavku("ciklus.trajanje")) * 1000;

    String datumPocetka = konfig.dajPostavku("preuzimanje.od");
    long datumPocetka_pocetakDana = pocetakDana(datumPocetka);
    long datumPocetka_krajDana = krajDana(datumPocetka);

    String datumZavrsetka = konfig.dajPostavku("preuzimanje.do");
    long datumZavrsetka_pocetakDana = pocetakDana(datumZavrsetka);

    long zadnjiZapis = vratiZadnjiZapis();
    if (zadnjiZapis > datumPocetka_pocetakDana) {
      String datumZadnjiZapisString =
          new SimpleDateFormat("dd.MM.yyyy").format(new Date(zadnjiZapis * 1000L));
      DateFormat formater = new SimpleDateFormat("dd.MM.yyyy");
      try {
        Date datumZadnjiZapis = formater.parse(datumZadnjiZapisString);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(datumZadnjiZapis);
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date zadnjiZapisDatumPlusJedan = calendar.getTime();
        SimpleDateFormat formater1 = new SimpleDateFormat("dd.MM.yyyy");
        String zadnjiZapisPlusJedanString = formater1.format(zadnjiZapisDatumPlusJedan);
        datumPocetka_pocetakDana = pocetakDana(zadnjiZapisPlusJedanString);
        datumPocetka_krajDana = krajDana(zadnjiZapisPlusJedanString);
      } catch (ParseException e) {
        e.printStackTrace();
      }
    }

    long danUsekundama = 24 * 60 * 60;

    while (datumPocetka_pocetakDana <= datumZavrsetka_pocetakDana) {
      String datum =
          new SimpleDateFormat("dd.MM.yyyy").format(new Date(datumPocetka_pocetakDana * 1000L));
      try {
        broj = odradiDan(datumPocetka_pocetakDana, datumPocetka_krajDana);
        jmsPosiljatelj
            .saljiPoruku("Na dan: " + datum + " preuzeto ukupno " + broj + " letova aviona.");
      } catch (NwtisRestIznimka | NamingException e) {
        e.printStackTrace();
      }

      datumPocetka_pocetakDana += danUsekundama;
      datumPocetka_krajDana += danUsekundama;

      try {
        long dretvaRadila = System.currentTimeMillis() / 1000 - oznakaPocetka;
        long spavanje = trajanjeCiklusa - dretvaRadila;
        Thread.sleep(spavanje);
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
    }
    interrupt();
  }

  @Override
  public void interrupt() {
    super.interrupt();
  }

  public long pocetakDana(String dan) {
    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
    String datumString = dan;
    Date datum = null;

    try {
      datum = format.parse(datumString);
    } catch (ParseException e) {
      e.printStackTrace();
    }

    Calendar c = Calendar.getInstance();
    c.setTime(datum);
    c.set(Calendar.HOUR_OF_DAY, 0);
    c.set(Calendar.MINUTE, 0);
    c.set(Calendar.SECOND, 0);
    long formatiraniDan = c.getTimeInMillis() / 1000;
    return formatiraniDan;
  }

  public long krajDana(String dan) {
    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
    String datumString = dan;
    Date datum = null;

    try {
      datum = format.parse(datumString);
    } catch (ParseException e) {
      e.printStackTrace();
    }

    Calendar c = Calendar.getInstance();
    c.setTime(datum);
    c.set(Calendar.HOUR_OF_DAY, 23);
    c.set(Calendar.MINUTE, 59);
    c.set(Calendar.SECOND, 59);
    long formatiraniDan = c.getTimeInMillis() / 1000;
    return formatiraniDan;
  }

  public long vratiZadnjiZapis() {
    String zadnjiDan = "";
    PreparedStatement pstmt = null;
    String query = "select FIRSTSEEN from LETOVI_POLASCI ORDER BY ID DESC LIMIT 1";

    try (var con = ds.getConnection()) {
      pstmt = con.prepareStatement(query);
      ResultSet rs = pstmt.executeQuery();
      while (rs.next()) {
        zadnjiDan = rs.getString("FIRSTSEEN");
      }
      rs.close();
      pstmt.close();
      con.close();
    } catch (Exception e) {
      Logger.getGlobal().log(Level.SEVERE, e.getMessage());
      System.out.println(e.getMessage());
    } finally {
      try {
        if (pstmt != null && !pstmt.isClosed()) {
          pstmt.close();
        }
      } catch (SQLException e) {
        Logger.getGlobal().log(Level.SEVERE, e.getMessage());
        System.out.println(e.getMessage());
      }
    }
    if (zadnjiDan.isEmpty()) {
      return 0;
    } else {
      return Long.parseLong(zadnjiDan);
    }
  }

  public int odradiDan(long datumPocetka_pocetakDana, long datumPocetka_krajDana)
      throws NwtisRestIznimka {
    broj = 0;
    List<LetAviona> listaLetova = new ArrayList<LetAviona>();
    OSKlijent osk = new OSKlijent(konfig.dajPostavku("OpenSkyNetwork.korisnik"),
        konfig.dajPostavku("OpenSkyNetwork.lozinka"));
    String[] aerodromi = konfig.dajPostavku("aerodromi.sakupljanje").split(" ");
    for (int i = 0; i < aerodromi.length; i++) {
      if (osk.getDepartures(aerodromi[i], datumPocetka_pocetakDana,
          datumPocetka_krajDana) == null) {
        continue;
      } else {
        listaLetova =
            osk.getDepartures(aerodromi[i], datumPocetka_pocetakDana, datumPocetka_krajDana);
        broj += listaLetova.size();
        for (LetAviona letAviona : listaLetova) {
          spremiLet(letAviona);
        }
      }
    }
    return broj;
  }

  public void spremiLet(LetAviona let) {
    PreparedStatement pstmt = null;
    String query = "INSERT INTO LETOVI_POLASCI (ICAO24, FIRSTSEEN, ESTDEPARTUREAIRPORT, "
        + "LASTSEEN, ESTARRIVALAIRPORT, CALLSIGN, ESTDEPARTUREAIRPORTHORIZDISTANCE, ESTDEPARTUREAIRPORTVERTDISTANCE, "
        + "ESTARRIVALAIRPORTHORIZDISTANCE, ESTARRIVALAIRPORTVERTDISTANCE, "
        + "DEPARTUREAIRPORTCANDIDATESCOUNT, ARRIVALAIRPORTCANDIDATESCOUNT, STORED)"
        + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    long storedLong = (long) let.getFirstSeen() * 1000;
    Timestamp t = new Timestamp(storedLong);

    try (var con = ds.getConnection()) {
      pstmt = con.prepareStatement(query);
      pstmt.setString(1, let.getIcao24());
      pstmt.setInt(2, let.getFirstSeen());
      pstmt.setString(3, let.getEstDepartureAirport());
      pstmt.setInt(4, let.getLastSeen());
      if (let.getEstArrivalAirport() == null) {
        pstmt.setString(5, "");
      } else {
        pstmt.setString(5, let.getEstArrivalAirport());
      }
      pstmt.setString(6, let.getCallsign());
      pstmt.setInt(7, let.getEstDepartureAirportHorizDistance());
      pstmt.setInt(8, let.getEstDepartureAirportVertDistance());
      pstmt.setInt(9, let.getEstArrivalAirportHorizDistance());
      pstmt.setInt(10, let.getEstArrivalAirportVertDistance());
      pstmt.setInt(11, let.getDepartureAirportCandidatesCount());
      pstmt.setInt(12, let.getArrivalAirportCandidatesCount());
      pstmt.setTimestamp(13, t);
      pstmt.executeUpdate();
      pstmt.close();
      con.close();
    } catch (Exception e) {
      Logger.getGlobal().log(Level.SEVERE, e.getMessage());
      System.out.println(e.getMessage());
    } finally {
      try {
        if (pstmt != null && !pstmt.isClosed()) {
          pstmt.close();
        }
      } catch (SQLException e) {
        Logger.getGlobal().log(Level.SEVERE, e.getMessage());
        System.out.println(e.getMessage());
      }
    }
  }
}

