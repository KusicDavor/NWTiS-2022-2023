package org.foi.nwtis.podaci;

public record Udaljenost(String drzava, float km) {
}
