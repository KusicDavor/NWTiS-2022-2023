package org.foi.nwtis.dkusic.zadaca_3.web;

import java.io.IOException;
import org.foi.nwtis.dkusic.zadaca_3.zrna.JmsPosiljatelj;
import jakarta.inject.Inject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "SaljeJmsPoruku", urlPatterns = {"/SaljeJmsPoruku"})
public class SaljeJmsPoruku extends HttpServlet {

  private static final long serialVersionUID = 3311084860755528565L;

  @Inject
  JmsPosiljatelj jmsPosiljatelj;

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {
    try {
      String poruka = req.getParameter("poruka");
      if (poruka != null && poruka.trim().length() > 0) {
        jmsPosiljatelj.saljiPoruku(poruka);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
