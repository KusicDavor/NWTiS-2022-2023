package org.foi.nwtis.dkusic.zadaca_3.zrna;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import jakarta.annotation.Resource;
import jakarta.ejb.Stateless;
import jakarta.jms.Connection;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.JMSException;
import jakarta.jms.MessageProducer;
import jakarta.jms.Queue;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;

@Stateless
public class JmsPosiljatelj {
  static int brojacPoruka = 0;
  @Resource(mappedName = "jms/nwtis_qf_dz3")
  private ConnectionFactory connectionFactory;
  @Resource(mappedName = "jms/nwtis_queue_dz3")
  private Queue queue;

  public boolean saljiPoruku(String tekstPoruke) throws NamingException {
    boolean status = true;
    InitialContext ctx = new InitialContext();

    try {
      connectionFactory = (ConnectionFactory) ctx.lookup("jms/nwtis_qf_dz3");
      Connection connection = connectionFactory.createConnection();
      Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
      queue = (Queue) ctx.lookup("jms/nwtis_queue_dz3");
      MessageProducer messageProducer = session.createProducer(queue);
      TextMessage message = session.createTextMessage();

      String poruka = tekstPoruke;
      message.setText(poruka);
      messageProducer.send(message);
      messageProducer.close();
      connection.close();
    } catch (JMSException ex) {
      ex.printStackTrace();
      status = false;
    }
    return status;
  }

}
