package org.foi.nwtis.dkusic.zadaca_3.ws;

import org.foi.nwtis.PostavkeBazaPodataka;
import org.foi.nwtis.dkusic.zadaca_3.jpa.Airports;
import org.foi.nwtis.dkusic.zadaca_3.zrna.AirportFacade;
import org.foi.nwtis.dkusic.zadaca_3.zrna.Slusac;
import org.foi.nwtis.rest.klijenti.LIQKlijent;
import org.foi.nwtis.rest.klijenti.NwtisRestIznimka;
import org.foi.nwtis.rest.klijenti.OWMKlijent;
import org.foi.nwtis.rest.podaci.Lokacija;
import org.foi.nwtis.rest.podaci.MeteoPodaci;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

@WebService(serviceName = "meteo")
public class WsMeteo {
  @Resource(lookup = "java:app/jdbc/nwtis_bp")
  javax.sql.DataSource ds;

  public static PostavkeBazaPodataka konfig = Slusac.getkonfDB();

  @Inject
  AirportFacade airportFacade;

  @WebMethod
  public MeteoPodaci dajMeteo(@WebParam String icao) throws NwtisRestIznimka {
    OWMKlijent ovm = new OWMKlijent(konfig.dajPostavku("OpenWeatherMap.apikey"));
    if (icao == null || icao.trim().length() == 0) {
      return null;
    }
    Airports a = airportFacade.find(icao);
    String[] koord = a.getCoordinates().split(",");
    var lokacija = new Lokacija(koord[1], koord[0]);
    MeteoPodaci mp = ovm.getRealTimeWeather(lokacija.getLatitude(), lokacija.getLongitude());
    return mp;
  }

  @WebMethod
  public MeteoPodaci dajMeteoAdresa(@WebParam String adresa) throws NwtisRestIznimka {
    LIQKlijent liq = new LIQKlijent(konfig.dajPostavku("LocationIQ.apikey"));
    OWMKlijent ovm = new OWMKlijent(konfig.dajPostavku("OpenWeatherMap.apikey"));
    Lokacija lokacija = liq.getGeoLocation(adresa);
    MeteoPodaci mp = ovm.getRealTimeWeather(lokacija.getLatitude(), lokacija.getLongitude());
    return mp;
  }
}
