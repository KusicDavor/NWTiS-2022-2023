/*
 * To change this license header, choose License Headers in Project Properties. To change this
 * template file, choose Tools | Templates and open the template in the editor.
 */
package org.foi.nwtis.dkusic.zadaca_3.mvc;

import org.foi.nwtis.PostavkeBazaPodataka;
import org.foi.nwtis.dkusic.zadaca_3.ws.WsAerodromi.endpoint.Aerodromi;
import org.foi.nwtis.podaci.Slusac;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import jakarta.xml.ws.WebServiceRef;

/**
 *
 * @author NWTiS
 */
@Controller
@Path("aerodromi")
@RequestScoped
public class KontrolerAerodroma {
  @WebServiceRef(wsdlLocation = "http://localhost:8080/dkusic_zadaca_3_wa_1/aerodromi?wsdl")
  private Aerodromi service;

  public static PostavkeBazaPodataka konfig = Slusac.getkonfDB();
  public static final int brojKonf = Integer.parseInt(konfig.dajPostavku("stranica.brojRedova"));


  @Inject
  private Models model;

  @GET
  @Path("pocetak")
  @View("index.jsp")
  public void pocetak() {}

  @GET
  @Path("svi")
  @View("aerodromi.jsp")
  public void getAerodromi(@QueryParam("odBroja") int odBroja, @QueryParam("broj") int broj) {

    if (odBroja == 0) {
      odBroja = 1;
    }

    if (broj == 0) {
      broj = brojKonf;
    }

    try {
      var port = service.getWsAerodromiPort();
      var listaAerodroma = port.dajSveAerodrome(odBroja, broj);
      model.put("listaAerodroma", listaAerodroma);
      model.put("konfig", konfig);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @GET
  @Path("{icao}")
  @View("aerodrom.jsp")
  public void getAerodrom(@PathParam("icao") String icao) {
    try {
      var port = service.getWsAerodromiPort();
      var aerodrom = port.dajAerodromJpa(icao);
      model.put("konfig", konfig);
      model.put("aerodrom", aerodrom);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @GET
  @Path("{icaoOd}/{icaoDo}")
  @View("aerodromiUdaljenosti.jsp")
  public void getAerodromiUdaljenost(@PathParam("icaoOd") String icaoOd,
      @PathParam("icaoDo") String icaoDo) {
    try {
      var port = service.getWsAerodromiPort();
      var listaUdaljenosti = port.dajUdaljenostiAerodroma(icaoOd, icaoDo);
      model.put("konfig", konfig);
      model.put("listaUdaljenosti", listaUdaljenosti);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @GET
  @Path("{icao}/udaljenosti")
  @View("icaoUdaljenosti.jsp")
  public void getdaljenosti(@PathParam("icao") String icao, @QueryParam("odBroja") int odBroja,
      @QueryParam("broj") int broj) {

    if (odBroja == 0) {
      odBroja = 1;
    }

    if (broj == 0) {
      broj = brojKonf;
    }

    try {
      var port = service.getWsAerodromiPort();
      var listaUdaljenosti = port.dajSveUdaljenostiAerodroma(icao, odBroja, broj);
      model.put("listaUdaljenost", listaUdaljenosti);
      model.put("icao", icao);
      model.put("konfig", konfig);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @GET
  @Path("{icao}/najduljiPutDrzave")
  @View("icaoPut.jsp")
  public void getPut(@PathParam("icao") String icao) {
    try {
      var port = service.getWsAerodromiPort();
      var put = port.dajNajduljiPutDrzave(icao);
      model.put("put", put);
      model.put("konfig", konfig);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
