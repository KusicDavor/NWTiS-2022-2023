package org.foi.nwtis.dkusic.zadaca_3.zrna;

import java.util.ArrayList;
import java.util.List;
import jakarta.ejb.ActivationConfigProperty;
import jakarta.ejb.MessageDriven;
import jakarta.ejb.Singleton;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.TextMessage;

@MessageDriven(mappedName = "jms/nwtis_queue_dz3", activationConfig = {
    @ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge"),
    @ActivationConfigProperty(propertyName = "destinationType",
        propertyValue = "jakarta.jms.Queue")})

@Singleton
public class SakupljacJmsPoruka implements MessageListener {
  public static List<String> kolekcijaPoruka = new ArrayList<String>();

  @Override
  public void onMessage(Message poruka) {
    if (poruka instanceof TextMessage) {
      try {
        var msg = (TextMessage) poruka;
        System.out.println(msg.getText());
        kolekcijaPoruka.add(msg.getText());
      } catch (Exception ex) {
        ex.printStackTrace();
      }
    }
  }

  public List<String> vratiKolekciju() {
    return kolekcijaPoruka;
  }
}
