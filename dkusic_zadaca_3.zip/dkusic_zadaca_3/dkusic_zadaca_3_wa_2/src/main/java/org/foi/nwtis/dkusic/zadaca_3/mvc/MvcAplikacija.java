package org.foi.nwtis.dkusic.zadaca_3.mvc;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("mvc")
public class MvcAplikacija extends Application {

}
