/*
 * To change this license header, choose License Headers in Project Properties. To change this
 * template file, choose Tools | Templates and open the template in the editor.
 */
package org.foi.nwtis.dkusic.zadaca_3.mvc;

import org.foi.nwtis.PostavkeBazaPodataka;
import org.foi.nwtis.dkusic.zadaca_3.ws.WsMeteo.endpoint.Meteo;
import org.foi.nwtis.podaci.Slusac;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import jakarta.xml.ws.WebServiceRef;

/**
 *
 * @author NWTiS
 */
@Controller
@Path("meteo")
@RequestScoped
public class KontrolerMeteo {
  @WebServiceRef(wsdlLocation = "http://webpredmeti:8080/dkusic_zadaca_3_wa_1/meteo?wsdl")
  private Meteo serviceMeteo;

  public static PostavkeBazaPodataka konfig = Slusac.getkonfDB();
  public static final String brojKonf = konfig.dajPostavku("stranica.brojRedova");

  @Inject
  private Models model;

  @GET
  @Path("{icao}")
  @View("meteoPodaci.jsp")
  public void dajMeteo(@PathParam("icao") String icao) {
    try {
      var port = serviceMeteo.getWsMeteoPort();
      var meteoPodaci = port.dajMeteo(icao);
      model.put("konfig", konfig);
      model.put("meteoPodaci", meteoPodaci);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @GET
  @View("meteoPodaci.jsp")
  public void dajMeteoAdresa(@QueryParam("adresa") String adresa) {
    try {
      var port = serviceMeteo.getWsMeteoPort();
      var meteoPodaci = port.dajMeteoAdresa(adresa);
      model.put("konfig", konfig);
      model.put("meteoPodaci", meteoPodaci);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
