/*
 * To change this license header, choose License Headers in Project Properties. To change this
 * template file, choose Tools | Templates and open the template in the editor.
 */
package org.foi.nwtis.dkusic.zadaca_3.mvc;

import org.foi.nwtis.PostavkeBazaPodataka;
import org.foi.nwtis.dkusic.zadaca_3.zrna.SakupljacJmsPoruka;
import org.foi.nwtis.podaci.Slusac;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;

/**
 *
 * @author NWTiS
 */
@Controller
@Path("letovi")
@RequestScoped
public class KontrolerPoruke {

  public static PostavkeBazaPodataka konfig = Slusac.getkonfDB();
  public static final int brojKonf = Integer.parseInt(konfig.dajPostavku("stranica.brojRedova"));

  @Inject
  private Models model;

  @GET
  @Path("poruke")
  @View("pregledPoruka.jsp")
  public void pogledajPoruke() {
    try {
      SakupljacJmsPoruka sakupljac = new SakupljacJmsPoruka();
      model.put("konfig", konfig);
      model.put("poruke", sakupljac.vratiKolekciju());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
