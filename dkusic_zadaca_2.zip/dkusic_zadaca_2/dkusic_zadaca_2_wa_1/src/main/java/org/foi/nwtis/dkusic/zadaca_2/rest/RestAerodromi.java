package org.foi.nwtis.dkusic.zadaca_2.rest;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.podaci.Aerodrom;
import org.foi.nwtis.podaci.Lokacija;
import org.foi.nwtis.podaci.Udaljenost;
import org.foi.nwtis.podaci.UdaljenostAerodromDrzava;
import com.google.gson.Gson;
import jakarta.annotation.Resource;
import jakarta.enterprise.context.RequestScoped;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * Klasa REST servisa za rad s upitima o aerodromima
 * 
 */
@Path("aerodromi")
@RequestScoped
public class RestAerodromi {

  @Resource(lookup = "java:app/jdbc/nwtis_bp")
  javax.sql.DataSource ds;

  /**
   * Metoda za dohvat svih aerodroma
   * 
   * @param broj količina zapisa koju želimo dohvatiti iz baze podataka
   * @param odBroja oznaka reda od kojeg želimo dohvatiti zapise iz baze podataka
   * @return odgovor lista aerodroma zapakiranih u json
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public Response dajSveAerodrome(@QueryParam("odBroja") @DefaultValue("1") int odBroja,
      @QueryParam("broj") @DefaultValue("20") int broj) {
    List<Aerodrom> aerodromi = new ArrayList<Aerodrom>();
    PreparedStatement pstmt = null;

    String query = "select * from AIRPORTS LIMIT ? OFFSET ?";
    try (var con = ds.getConnection()) {
      pstmt = con.prepareStatement(query);
      pstmt.setInt(1, broj);
      pstmt.setInt(2, odBroja);

      ResultSet rs = pstmt.executeQuery();
      while (rs.next()) {
        String icao = rs.getString("ICAO");
        String naziv = rs.getString("NAME");
        String drzava = rs.getString("ISO_COUNTRY");
        String[] lok = rs.getString("COORDINATES").split(",");
        Lokacija lokacija = new Lokacija();
        lokacija.postavi(lok[0], lok[1]);
        Aerodrom aerodrom = new Aerodrom(icao, naziv, drzava, lokacija);
        aerodromi.add(aerodrom);

      }
      rs.close();
      pstmt.close();
      con.close();
    } catch (Exception e) {
      Logger.getGlobal().log(Level.SEVERE, e.getMessage());
      System.out.println(e.getMessage());
    } finally {
      try {
        if (pstmt != null && !pstmt.isClosed()) {
          pstmt.close();
        }
      } catch (SQLException e) {
        Logger.getGlobal().log(Level.SEVERE, e.getMessage());
        System.out.println(e.getMessage());
      }
    }

    var gson = new Gson();
    var jsonAerodromi = gson.toJson(aerodromi);

    var odgovor = Response.ok().entity(jsonAerodromi).build();
    return odgovor;
  }

  /**
   * Metoda za dohvat informacija između dva aerodroma
   * 
   * @param icaoOd oznaka prvog aerodroma
   * @param icaoDo oznaka drugog aerodroma
   * @return odgovor lista udaljenosti po državama zapakirana u json
   */
  @Path("{icaoOd}/{icaoDo}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public Response dajUdaljenostiIzmeđuDvaAerodoma(@PathParam("icaoOd") String icaoOd,
      @PathParam("icaoDo") String icaoDo) {

    List<Udaljenost> lista = new ArrayList<Udaljenost>();
    PreparedStatement pstmt = null;

    String query =
        "select ICAO_FROM, ICAO_TO, COUNTRY, DIST_CTRY from AIRPORTS_DISTANCE_MATRIX WHERE "
            + "ICAO_FROM = ? AND ICAO_TO = ?";

    try (var con = ds.getConnection()) {

      pstmt = con.prepareStatement(query);
      pstmt.setString(1, icaoOd);
      pstmt.setString(2, icaoDo);

      ResultSet rs = pstmt.executeQuery();

      while (rs.next()) {
        String drzava = rs.getString("COUNTRY");
        float udaljDrzava = rs.getFloat("DIST_CTRY");
        Udaljenost udaljenost = new Udaljenost(drzava, udaljDrzava);
        lista.add(udaljenost);

      }
      rs.close();
      pstmt.close();
      con.close();
    } catch (Exception e) {
      Logger.getGlobal().log(Level.SEVERE, e.getMessage());
      System.out.println(e.getMessage());
    } finally {
      try {
        if (pstmt != null && !pstmt.isClosed()) {
          pstmt.close();
        }
      } catch (SQLException e) {
        Logger.getGlobal().log(Level.SEVERE, e.getMessage());
        System.out.println(e.getMessage());
      }
    }

    var gson = new Gson();
    var jsonUdaljenosti = gson.toJson(lista);
    var odgovor = Response.ok().entity(jsonUdaljenosti).build();

    return odgovor;
  }

  /**
   * Metoda za dohvat informacija o udaljenosti između odabranog aerodroma i svih drugih
   * 
   * @param icao oznaka aerodroma
   * @param broj količina zapisa koju želimo dohvatiti iz baze podataka
   * @param odBroja oznaka reda od kojeg želimo dohvatiti zapise iz baze podataka
   * @return odgovor lista udaljenosti sa oznakama aerodroma zapakirana u json
   */
  @Path("{icao}/udaljenosti")
  @GET
  @Produces({MediaType.APPLICATION_JSON})
  public Response dajAerodrom(@PathParam("icao") String icao,
      @QueryParam("odBroja") @DefaultValue("1") int odBroja,
      @QueryParam("broj") @DefaultValue("20") int broj) {

    List<UdaljenostAerodromDrzava> listaUdaljenosti = new ArrayList<UdaljenostAerodromDrzava>();
    PreparedStatement pstmt = null;

    String query =
        "SELECT * FROM AIRPORTS_DISTANCE_MATRIX adm WHERE adm.ICAO_FROM = ? LIMIT ? OFFSET ?;";
    try (var con = ds.getConnection()) {

      pstmt = con.prepareStatement(query);
      pstmt.setString(1, icao);
      pstmt.setInt(2, broj);
      pstmt.setInt(3, odBroja);

      ResultSet rs = pstmt.executeQuery();

      while (rs.next()) {
        String aerodrom = rs.getString("ICAO_TO");
        String drzava = rs.getString("COUNTRY");
        float km = rs.getFloat("DIST_TOT");

        UdaljenostAerodromDrzava udaljenosti = new UdaljenostAerodromDrzava(aerodrom, drzava, km);
        listaUdaljenosti.add(udaljenosti);
      }

      rs.close();
      pstmt.close();
      con.close();
    } catch (Exception e) {
      Logger.getGlobal().log(Level.SEVERE, e.getMessage());
      System.out.println(e.getMessage());
    } finally {
      try {
        if (pstmt != null && !pstmt.isClosed()) {
          pstmt.close();
        }
      } catch (SQLException e) {
        Logger.getGlobal().log(Level.SEVERE, e.getMessage());
        System.out.println(e.getMessage());
      }
    }

    var gson = new Gson();
    var jsonUdaljenosti = gson.toJson(listaUdaljenosti);

    Response odgovor = Response.ok().entity(jsonUdaljenosti).build();
    return odgovor;
  }

  /**
   * Metoda za dohvat informacija o odabranom aerodromu
   * 
   * @param icao oznaka aerodroma
   * @return odgovor klasa Aerodrom sa informacijama o odabranom aerodromu zapakirana u json
   */
  @GET
  @Produces({MediaType.APPLICATION_JSON})
  @Path("{icao}")
  public Response dajUdaljenostiIzmeđuSvihAerodoma(@PathParam("icao") String icao) {

    Aerodrom trazeni = null;
    PreparedStatement pstmt = null;
    Response odgovor = null;

    String query = "SELECT * FROM AIRPORTS a WHERE a.ICAO  = ?;";
    try (var con = ds.getConnection()) {

      pstmt = con.prepareStatement(query);
      pstmt.setString(1, icao);

      ResultSet rs = pstmt.executeQuery();

      while (rs.next()) {
        String icao1 = rs.getString("ICAO");
        String naziv = rs.getString("NAME");
        String drzava = rs.getString("ISO_COUNTRY");
        String[] koordinate = rs.getString("COORDINATES").split(",");
        trazeni = new Aerodrom();
        trazeni.setIcao(icao1);
        trazeni.setNaziv(naziv);
        trazeni.setDrzava(drzava);
        Lokacija lokacija = new Lokacija();
        lokacija.postavi(koordinate[0], koordinate[1]);
        trazeni.setLokacija(lokacija);
      }

      rs.close();
      pstmt.close();
      con.close();
    } catch (Exception e) {
      Logger.getGlobal().log(Level.SEVERE, e.getMessage());
      System.out.println(e.getMessage());
    } finally {
      try {
        if (pstmt != null && !pstmt.isClosed()) {
          pstmt.close();
        }
      } catch (SQLException e) {
        Logger.getGlobal().log(Level.SEVERE, e.getMessage());
        System.out.println(e.getMessage());
      }
    }

    var gson = new Gson();
    var jsonAerodrom = gson.toJson(trazeni);

    if (trazeni != null) {
      odgovor = Response.ok().entity(jsonAerodrom).build();
    } else {
      odgovor = Response.status(Response.Status.NOT_FOUND).build();
    }
    return odgovor;
  }

  /**
   * Metoda za dohvat podataka o najvećoj udaljenosti za traženi aerodrom
   *
   * @param icao oznaka aerodroma
   * @return odgovor udaljenost do najdaljeg aerodroma sa oznakom aerodroma i državom u kojoj se
   *         nalazi
   */
  @GET
  @Produces({MediaType.APPLICATION_JSON})
  @Path("{icao}/najduljiPutDrzave")
  public Response dajNajduljiPutDrzave(@PathParam("icao") String icao) {

    PreparedStatement pstmt = null;
    Response odgovor = null;
    UdaljenostAerodromDrzava rezultat = null;

    String query = "SELECT * FROM AIRPORTS_DISTANCE_MATRIX adm WHERE adm.ICAO_FROM  = ?;";
    try (var con = ds.getConnection()) {

      pstmt = con.prepareStatement(query);
      pstmt.setString(1, icao);

      ResultSet rs = pstmt.executeQuery();
      float najveca_udaljenost = 0;
      String drzava = "";
      String icao_to = "";

      while (rs.next()) {
        float udaljenost = rs.getFloat("DIST_CTRY");
        if (udaljenost > najveca_udaljenost) {
          najveca_udaljenost = udaljenost;
          icao_to = rs.getString("ICAO_TO");
          drzava = rs.getString("COUNTRY");
        }

        rezultat = new UdaljenostAerodromDrzava(icao_to, drzava, najveca_udaljenost);
      }

      rs.close();
      pstmt.close();
      con.close();
    } catch (Exception e) {
      Logger.getGlobal().log(Level.SEVERE, e.getMessage());
      System.out.println(e.getMessage());
    } finally {
      try {
        if (pstmt != null && !pstmt.isClosed()) {
          pstmt.close();
        }
      } catch (SQLException e) {
        Logger.getGlobal().log(Level.SEVERE, e.getMessage());
        System.out.println(e.getMessage());
      }
    }

    var gson = new Gson();
    var jsonNajvecaUdaljenost = gson.toJson(rezultat);

    if (rezultat.icao() != null) {
      odgovor = Response.ok().entity(jsonNajvecaUdaljenost).build();
    } else {
      odgovor = Response.status(Response.Status.NOT_FOUND).build();
    }
    return odgovor;
  }
}
