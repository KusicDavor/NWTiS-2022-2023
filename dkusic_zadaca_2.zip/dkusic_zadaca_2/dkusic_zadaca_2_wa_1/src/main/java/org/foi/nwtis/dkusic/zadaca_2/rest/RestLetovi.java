package org.foi.nwtis.dkusic.zadaca_2.rest;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.foi.nwtis.PostavkeBazaPodataka;
import org.foi.nwtis.dkusic.zadaca_2.slusaci.Slusac;
import org.foi.nwtis.rest.klijenti.NwtisRestIznimka;
import org.foi.nwtis.rest.klijenti.OSKlijent;
import org.foi.nwtis.rest.podaci.LetAviona;
import com.google.gson.Gson;
import jakarta.annotation.Resource;
import jakarta.enterprise.context.RequestScoped;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * Klasa REST servisa za rad s upitima o letovima
 * 
 */
@Path("letovi")
@RequestScoped
public class RestLetovi {

  @Resource(lookup = "java:app/jdbc/nwtis_bp")
  javax.sql.DataSource ds;

  PostavkeBazaPodataka konfig = Slusac.getkonfDB();
  String username = konfig.dajPostavku("OpenSkyNetwork.korisnik");
  String password = konfig.dajPostavku("OpenSkyNetwork.lozinka");

  /**
   * Metoda za dohvat svih letova odabranog aerodroma na odabrani dan
   * 
   * @param icao ICAO oznaka odabranog aerodroma
   * @param dan odabir dana za kojeg želimo vidjeti letove
   * @param broj količina zapisa koju želimo dohvatiti iz baze podataka
   * @param odBroja oznaka reda od kojeg želimo dohvatiti zapise iz baze podataka
   * @return odgovor lista letova zapakiranih u json
   */
  @Path("{icao}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public Response dajUdaljenostiIzmeđuDvaAerodoma(@PathParam("icao") String icao,
      @QueryParam("dan") String dan, @QueryParam("odBroja") @DefaultValue("1") int odBroja,
      @QueryParam("broj") @DefaultValue("20") int broj) {

    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy.");
    String datumString = dan;
    Date datum = null;

    try {
      datum = format.parse(datumString);
    } catch (ParseException e) {
      e.printStackTrace();
    }

    Calendar c = Calendar.getInstance();
    c.setTime(datum);
    c.set(Calendar.HOUR_OF_DAY, 0);
    c.set(Calendar.MINUTE, 0);
    c.set(Calendar.SECOND, 0);
    long pocetak_dana = c.getTimeInMillis() / 1000;

    c.set(Calendar.HOUR_OF_DAY, 23);
    c.set(Calendar.MINUTE, 59);
    c.set(Calendar.SECOND, 59);
    long kraj_dana = c.getTimeInMillis() / 1000;

    OSKlijent osk = new OSKlijent(username, password);
    List<LetAviona> listaLetova = new ArrayList<LetAviona>();

    try {
      listaLetova = osk.getDepartures(icao, pocetak_dana, kraj_dana);
    } catch (NwtisRestIznimka e) {
      e.printStackTrace();
    }

    var gson = new Gson();
    var jsonlistaLetova = gson.toJson(listaLetova);
    var odgovor = Response.ok().entity(jsonlistaLetova).build();
    return odgovor;
  }

  /**
   * Metoda za dohvat svih letova između odabranih aerodroma
   * 
   * @param icaoOd ICAO oznaka prvog aerodroma
   * @param icaoDo ICAO oznaka drugog aerodroma
   * @param dan odabir dana za kojeg želimo vidjeti letove
   * @return odgovor lista letova između aerodroma zapakiranih u json
   */
  @Path("{icaoOd}/{icaoDo}")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public Response dajLetoveIzmeđuDvaAerodoma(@PathParam("icaoOd") String icaoOd,
      @PathParam("icaoDo") String icaoDo, @QueryParam("dan") String dan) {

    SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy.");
    String datumString = dan;
    Date datum = null;

    try {
      datum = format.parse(datumString);
    } catch (ParseException e) {
      e.printStackTrace();
    }

    Calendar c = Calendar.getInstance();
    c.setTime(datum);
    c.set(Calendar.HOUR_OF_DAY, 0);
    c.set(Calendar.MINUTE, 0);
    c.set(Calendar.SECOND, 0);
    long pocetak_dana = c.getTimeInMillis() / 1000;

    c.set(Calendar.HOUR_OF_DAY, 23);
    c.set(Calendar.MINUTE, 59);
    c.set(Calendar.SECOND, 59);
    long kraj_dana = c.getTimeInMillis() / 1000;

    OSKlijent osk = new OSKlijent(username, password);
    List<LetAviona> listaLetova = new ArrayList<LetAviona>();
    List<LetAviona> listaRez = new ArrayList<LetAviona>();

    try {
      listaLetova = osk.getDepartures(icaoOd, pocetak_dana, kraj_dana);

      for (LetAviona letAviona : listaLetova) {
        if (letAviona.getEstArrivalAirport() != null) {
          if (letAviona.getEstArrivalAirport().equals(icaoDo)) {
            listaRez.add(letAviona);
          }
        }
      }
    } catch (NwtisRestIznimka e) {
      e.printStackTrace();
    }

    var gson = new Gson();
    var jsonlistaLetova = gson.toJson(listaRez);
    var odgovor = Response.ok().entity(jsonlistaLetova).build();
    return odgovor;
  }

  /**
   * Metoda za spremanje odabranog leta u bazu podataka
   * 
   * @param jsonLet odabrani let za spremanje u json zapisu
   * @throws IOException baca exception ako je došlo do pogreške u spremanju
   * @return Response status o ishodu akcije spremanja leta u bazu podataka s porukom
   */
  @POST
  @Produces(MediaType.APPLICATION_JSON)
  public Response primiPost(String jsonLet) throws IOException {

    boolean rezultat = false;
    Gson gson = new Gson();
    LetAviona let = gson.fromJson(jsonLet, LetAviona.class);

    PreparedStatement pstmt = null;
    String query = "INSERT INTO LETOVI_POLASCI (ICAO24, FIRSTSEEN, ESTDEPARTUREAIRPORT, "
        + "LASTSEEN, ESTARRIVALAIRPORT, CALLSIGN, ESTDEPARTUREAIRPORTHORIZDISTANCE, ESTDEPARTUREAIRPORTVERTDISTANCE, "
        + "ESTARRIVALAIRPORTHORIZDISTANCE, ESTARRIVALAIRPORTVERTDISTANCE, "
        + "DEPARTUREAIRPORTCANDIDATESCOUNT, ARRIVALAIRPORTCANDIDATESCOUNT, STORED)"
        + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    long storedLong = (long) let.getFirstSeen() * 1000;
    Timestamp t = new Timestamp(storedLong);

    try (var con = ds.getConnection()) {
      pstmt = con.prepareStatement(query);
      pstmt.setString(1, let.getIcao24());
      pstmt.setInt(2, let.getFirstSeen());
      pstmt.setString(3, let.getEstDepartureAirport());
      pstmt.setInt(4, let.getLastSeen());
      if (let.getEstArrivalAirport() == null) {
        pstmt.setString(5, "");
      } else {
        pstmt.setString(5, let.getEstArrivalAirport());
      }
      pstmt.setString(6, let.getCallsign());
      pstmt.setInt(7, let.getEstDepartureAirportHorizDistance());
      pstmt.setInt(8, let.getEstDepartureAirportVertDistance());
      pstmt.setInt(9, let.getEstArrivalAirportHorizDistance());
      pstmt.setInt(10, let.getEstArrivalAirportVertDistance());
      pstmt.setInt(11, let.getDepartureAirportCandidatesCount());
      pstmt.setInt(12, let.getArrivalAirportCandidatesCount());
      pstmt.setTimestamp(13, t);


      int insertanje = pstmt.executeUpdate();
      if (insertanje > 0) {
        rezultat = true;
      }

      pstmt.close();
      con.close();
    } catch (Exception e) {
      Logger.getGlobal().log(Level.SEVERE, e.getMessage());
      System.out.println(e.getMessage());
    } finally {
      try {
        if (pstmt != null && !pstmt.isClosed()) {
          pstmt.close();
        }
      } catch (SQLException e) {
        Logger.getGlobal().log(Level.SEVERE, e.getMessage());
        System.out.println(e.getMessage());
      }
    }

    if (rezultat) {
      return Response.status(Response.Status.OK).entity("Let je uspješno pohranjen.").build();
    } else {
      return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
          .entity("Let nije uspješno pohranjen.").build();
    }
  }

  /**
   * Metoda za dohvat spremljenih letova iz baze podataka
   * 
   * @return mapa Mapa zapakirana u json, Integer predstavlja ID leta u bazi, LetAviona je jedan let
   */
  @Path("spremljeni")
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public Response dajSpremljene() {
    PreparedStatement pstmt = null;
    Map<Integer, LetAviona> mapa = new HashMap<Integer, LetAviona>();
    String query = "select * from LETOVI_POLASCI";
    try (var con = ds.getConnection()) {
      pstmt = con.prepareStatement(query);
      ResultSet rs = pstmt.executeQuery();
      while (rs.next()) {
        Integer id = rs.getInt("ID");
        String icao24 = rs.getString("ICAO24");
        Integer firstseen = rs.getInt("FIRSTSEEN");
        String estDepAir = rs.getString("ESTDEPARTUREAIRPORT");
        Integer lastseen = rs.getInt("LASTSEEN");
        String eastArrAir = rs.getString("ESTARRIVALAIRPORT");
        String callsign = rs.getString("CALLSIGN");
        Integer estDepAirHor = rs.getInt("ESTDEPARTUREAIRPORTHORIZDISTANCE");
        Integer estDepAirVer = rs.getInt("ESTDEPARTUREAIRPORTVERTDISTANCE");
        Integer estArrAirHor = rs.getInt("ESTARRIVALAIRPORTHORIZDISTANCE");
        Integer estArrAirVer = rs.getInt("ESTARRIVALAIRPORTVERTDISTANCE");
        Integer depAirCan = rs.getInt("DEPARTUREAIRPORTCANDIDATESCOUNT");
        Integer arrAirCan = rs.getInt("DEPARTUREAIRPORTCANDIDATESCOUNT");
        LetAviona let = new LetAviona(icao24, firstseen, estDepAir, lastseen, eastArrAir, callsign,
            estDepAirHor, estDepAirVer, estArrAirHor, estArrAirVer, depAirCan, arrAirCan);
        mapa.put(id, let);
      }
      rs.close();
      pstmt.close();
      con.close();
    } catch (Exception e) {
      Logger.getGlobal().log(Level.SEVERE, e.getMessage());
      System.out.println(e.getMessage());
    } finally {
      try {
        if (pstmt != null && !pstmt.isClosed()) {
          pstmt.close();
        }
      } catch (SQLException e) {
        Logger.getGlobal().log(Level.SEVERE, e.getMessage());
        System.out.println(e.getMessage());
      }
    }

    var gson = new Gson();
    var jsonMapa = gson.toJson(mapa);
    var odgovor = Response.ok().entity(jsonMapa).build();
    return odgovor;
  }

  /**
   * Metoda za brisanje leta iz spremljenih letova u bazi
   * 
   * @param id jedinstvena oznaka reda odabranog leta u bazi podataka
   * @return Response status o ishodu akcije brisanja leta iz baze podataka s porukom
   */
  @Path("{id}")
  @DELETE
  @Produces(MediaType.APPLICATION_JSON)
  public Response obrisiLet(@PathParam("id") String id) {
    int obrisan = 0;
    PreparedStatement pstmt = null;
    String query = "DELETE FROM LETOVI_POLASCI WHERE ID = ?";
    try (var con = ds.getConnection()) {

      pstmt = con.prepareStatement(query);
      pstmt.setString(1, id);
      obrisan = pstmt.executeUpdate();
      pstmt.close();
      con.close();
    } catch (Exception e) {
      Logger.getGlobal().log(Level.SEVERE, e.getMessage());
      System.out.println(e.getMessage());
    } finally {
      try {
        if (pstmt != null && !pstmt.isClosed()) {
          pstmt.close();
        }
      } catch (SQLException e) {
        Logger.getGlobal().log(Level.SEVERE, e.getMessage());
        System.out.println(e.getMessage());
      }
    }

    if (obrisan == 1) {
      return Response.status(Response.Status.OK).entity("Let je uspješno obrisan.").build();
    } else {
      return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
          .entity("Let nije uspješno obrisan.").build();
    }
  }
}
