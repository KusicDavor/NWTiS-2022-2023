/*
 * To change this license header, choose License Headers in Project Properties. To change this
 * template file, choose Tools | Templates and open the template in the editor.
 */
package org.foi.nwtis.dkusic.zadaca_2.mvc;

import org.foi.nwtis.PostavkeBazaPodataka;
import org.foi.nwtis.dkusic.zadaca_2.podaci.Slusac;
import org.foi.nwtis.dkusic.zadaca_2.rest.RestKlijentAerodroma;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;

/**
 * Klasa tipa kontroler za upravljanje zahtjevima o aerodromima
 * 
 * @author Davor Kušić
 */
@Controller
@Path("aerodromi")
@RequestScoped
public class KontrolerAerodroma {
  /**
   * Sprema konfiguraciju u varijablu klase PostavkeBazaPodataka
   */
  public static PostavkeBazaPodataka konfig = Slusac.getkonfDB();

  @Inject
  private Models model;

  /**
   * Postavlja putanju "pocetak" koja prikazuje početnu stranicu (indeks.jsp), koristi GET metodu
   */
  @GET
  @Path("pocetak")
  @View("indeks.jsp")
  public void pocetak() {
    model.put("konfig", konfig);
  }

  /**
   * Metoda za proslijeđivanje zahtjeva za dohvat svih aerodroma prema Rest servisu sa funkcijom
   * straničenja, koristi GET metodu
   * 
   * @param broj količina zapisa koju želimo dohvatiti iz baze podataka
   * @param odBroja oznaka reda od kojeg želimo dohvatiti zapise iz baze podataka
   */
  @GET
  @View("aerodromi.jsp")
  public void getAerodromi(@QueryParam("odBroja") @DefaultValue("1") int odBroja,
      @QueryParam("broj") @DefaultValue("20") int broj) {
    try {
      RestKlijentAerodroma rca = new RestKlijentAerodroma();
      var listaAerodroma = rca.getAerodromi(odBroja, broj);
      model.put("listaAerodroma", listaAerodroma);
      model.put("konfig", konfig);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Metoda za proslijeđivanje zahtjeva za dohvat podataka o odabranom aerodromu prema Rest servisu,
   * koristi GET metodu
   * 
   * @param icao oznaka aerodroma
   */
  @GET
  @Path("{icao}")
  @View("aerodrom.jsp")
  public void getAerodrom(@PathParam("icao") String icao) {
    try {
      RestKlijentAerodroma rca = new RestKlijentAerodroma();
      var aerodrom = rca.getAerodrom(icao);
      model.put("aerodrom", aerodrom);
      model.put("konfig", konfig);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Metoda za proslijeđivanje zahtjeva Rest servisu za dohvat podataka o državi i najvećoj
   * udaljenosti kroz koju prolazi putanja od traženog aerodroma prema svim drugim, koristi GET
   * metodu, koristi GET metodu
   * 
   * @param icao oznaka aerodroma
   */
  @GET
  @Path("{icao}/najduljiPutDrzave")
  @View("icaoPut.jsp")
  public void getPut(@PathParam("icao") String icao) {
    try {
      RestKlijentAerodroma rca = new RestKlijentAerodroma();
      var put = rca.getPut(icao);
      model.put("put", put);
      model.put("konfig", konfig);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Metoda za proslijeđivanje zahtjeva Rest servisu za dohvat podataka o udaljenosti dva aerodroma
   * kroz države te ukupnoj udaljenosti, koristi GET metodu
   * 
   * @param icaoOd ICAO oznaka prvog aerodroma
   * @param icaoDo ICAO oznaka drugog aerodroma
   */
  @GET
  @Path("{icaoOd}/{icaoDo}")
  @View("aerodromiUdaljenosti.jsp")
  public void getAerodromiUdaljenost1(@PathParam("icaoOd") String icaoOd,
      @PathParam("icaoDo") String icaoDo) {
    try {
      RestKlijentAerodroma rca = new RestKlijentAerodroma();
      var listaUdaljenosti = rca.getAerodromiUdaljenost(icaoOd, icaoDo);
      model.put("udaljenosti", listaUdaljenosti);
      model.put("konfig", konfig);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Metoda za proslijeđivanje zahtjeva Rest servisu za dohvat podataka o udaljenosti između
   * odabranog aerodroma i svih drugih sa funkcijom straničenja, koristi GET metodu
   * 
   * @param icao ICAO oznaka aerodroma * @param broj količina zapisa koju želimo dohvatiti iz baze
   *        podataka
   * @param odBroja oznaka reda od kojeg želimo dohvatiti zapise iz baze podataka
   * @param broj količina zapisa koju želimo dohvatiti iz baze podataka
   */
  @GET
  @Path("{icao}/udaljenosti")
  @View("icaoUdaljenosti.jsp")
  public void getdaljenosti(@PathParam("icao") String icao,
      @QueryParam("odBroja") @DefaultValue("1") int odBroja,
      @QueryParam("broj") @DefaultValue("20") int broj) {

    try {
      RestKlijentAerodroma rca = new RestKlijentAerodroma();
      var listaUdaljenost = rca.getUdaljenosti(icao, odBroja, broj);
      model.put("listaUdaljenost", listaUdaljenost);
      model.put("icao", icao);
      model.put("konfig", konfig);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
