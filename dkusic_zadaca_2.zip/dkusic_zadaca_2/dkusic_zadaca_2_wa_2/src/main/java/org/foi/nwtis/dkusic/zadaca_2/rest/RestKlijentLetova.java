package org.foi.nwtis.dkusic.zadaca_2.rest;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.foi.nwtis.PostavkeBazaPodataka;
import org.foi.nwtis.dkusic.zadaca_2.podaci.Slusac;
import org.foi.nwtis.rest.podaci.LetAviona;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import jakarta.ws.rs.ClientErrorException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.Invocation;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class RestKlijentLetova {

  public static PostavkeBazaPodataka konfig = Slusac.getkonfDB();

  public RestKlijentLetova() {}

  public List<LetAviona> getLetoviDan(String icao, String dan, int broj, int odBroja) {
    RestKKlijent rc = new RestKKlijent();
    List<LetAviona> listaLetova = new ArrayList<LetAviona>();
    listaLetova = rc.getLetoviDan(icao, dan, broj, odBroja);
    return listaLetova;
  }

  public List<LetAviona> getLetoviAerodromi(String icaoOd, String icaoDo, String dan) {
    RestKKlijent rc = new RestKKlijent();
    List<LetAviona> listaLetova = new ArrayList<LetAviona>();
    listaLetova = rc.getLetoviAerodromi(icaoOd, icaoDo, dan);
    return listaLetova;
  }

  public Response postaj(String enkodiraniJson) {
    RestKKlijent rc = new RestKKlijent();
    return rc.postaj(enkodiraniJson);
  }

  public Response obrisi(Integer id) {
    RestKKlijent rc = new RestKKlijent();
    return rc.obrisi(id);
  }

  public Map<Integer, LetAviona> getSpremljeni() {
    RestKKlijent rc = new RestKKlijent();
    Map<Integer, LetAviona> listaLetova = new HashMap<Integer, LetAviona>();
    listaLetova = rc.getSpremljeni();
    return listaLetova;
  }

  static class RestKKlijent {

    private final WebTarget webTarget;
    private final Client client;
    private static final String BASE_URI = konfig.dajPostavku("adresa.wa_1");
    // private static final String BASE_URI = "http://localhost:8080/dkusic_zadaca_2_wa_1/api";

    public RestKKlijent() {
      client = ClientBuilder.newClient();
      webTarget = client.target(BASE_URI).path("letovi");
    }

    public Response obrisi(Integer id) {
      WebTarget resource = webTarget.path(String.valueOf(id));
      Response response = resource.request().delete();
      return response;
    }

    public List<LetAviona> getLetoviDan(String icao, String dan, int broj, int odBroja)
        throws ClientErrorException {
      WebTarget resource = webTarget;
      resource = resource.path(java.text.MessageFormat.format("{0}", new Object[] {icao}))
          .queryParam("dan", dan).queryParam("broj", broj).queryParam("odBroja", odBroja);
      Invocation.Builder request = resource.request(MediaType.APPLICATION_JSON);
      if (request.get(String.class).isEmpty()) {
        return null;
      }
      Gson gson = new Gson();
      var listaTip = new TypeToken<List<LetAviona>>() {}.getType();
      List<LetAviona> listaLetova = gson.fromJson(request.get(String.class), listaTip);
      return listaLetova;
    }

    public List<LetAviona> getLetoviAerodromi(String icaoOd, String icaoDo, String dan)
        throws ClientErrorException {
      WebTarget resource = webTarget;
      resource =
          resource.path(java.text.MessageFormat.format("{0}/{1}", new Object[] {icaoOd, icaoDo}))
              .queryParam("dan", dan);
      Invocation.Builder request = resource.request(MediaType.APPLICATION_JSON);
      if (request.get(String.class).isEmpty()) {
        return null;
      }
      Gson gson = new Gson();
      var listaTip = new TypeToken<List<LetAviona>>() {}.getType();
      List<LetAviona> listaLetova = gson.fromJson(request.get(String.class), listaTip);
      return listaLetova;
    }

    public Response postaj(String enkodiraniJson) {
      String enkodirani = enkodiraniJson.replaceFirst(".*?=", "");
      String dekodirani = URLDecoder.decode(enkodirani, StandardCharsets.UTF_8);
      WebTarget resource = webTarget;
      Response response =
          resource.request(MediaType.APPLICATION_JSON).post(Entity.json(dekodirani.toString()));
      return response;
    }

    public Map<Integer, LetAviona> getSpremljeni() throws ClientErrorException {
      WebTarget resource = webTarget;
      resource = resource.path("spremljeni");
      Invocation.Builder request = resource.request(MediaType.APPLICATION_JSON);
      if (request.get(String.class).isEmpty()) {
        return null;
      }
      Gson gson = new Gson();
      var mapaTip = new TypeToken<Map<Integer, LetAviona>>() {}.getType();
      Map<Integer, LetAviona> mapa = gson.fromJson(request.get(String.class), mapaTip);
      return mapa;
    }

    public void close() {
      client.close();
    }
  }
}
