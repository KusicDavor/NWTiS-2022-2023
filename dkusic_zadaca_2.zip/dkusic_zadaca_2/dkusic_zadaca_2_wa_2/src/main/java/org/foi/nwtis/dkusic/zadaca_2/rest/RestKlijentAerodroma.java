package org.foi.nwtis.dkusic.zadaca_2.rest;

import java.util.ArrayList;
import java.util.List;
import org.foi.nwtis.PostavkeBazaPodataka;
import org.foi.nwtis.dkusic.zadaca_2.podaci.Aerodrom;
import org.foi.nwtis.dkusic.zadaca_2.podaci.Slusac;
import org.foi.nwtis.dkusic.zadaca_2.podaci.Udaljenost;
import org.foi.nwtis.dkusic.zadaca_2.podaci.UdaljenostAerodromDrzava;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import jakarta.ws.rs.ClientErrorException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Invocation;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;

/**
 * Klasa REST servisa
 */
public class RestKlijentAerodroma {
  /**
   * Sprema konfiguraciju u varijablu klase PostavkeBazaPodataka
   */
  public static PostavkeBazaPodataka konfig = Slusac.getkonfDB();

  /**
   * Konstruktor klase RestKlijentAerodroma()
   */
  public RestKlijentAerodroma() {}

  /**
   * Metoda za dohvat podataka o svim aerodromima
   * 
   * @param broj količina zapisa koju želimo dohvatiti iz baze podataka
   * @param odBroja oznaka reda od kojeg želimo dohvatiti zapise iz baze podataka
   * @return vraća listu Aerodroma
   */
  public List<Aerodrom> getAerodromi(int odBroja, int broj) {
    RestKKlijent rc = new RestKKlijent();
    List<Aerodrom> aerodromi = new ArrayList<Aerodrom>();
    aerodromi = rc.getAerodromi(odBroja, broj);

    return aerodromi;
  }

  /**
   * Metoda za dohvat podataka o odabranom aerodromu
   * 
   * @param icao ICAO oznaka odabranog aerodroma
   * @return vraća varijablu klase Aerodrom s podacima
   */
  public Aerodrom getAerodrom(String icao) {
    RestKKlijent rc = new RestKKlijent();
    Aerodrom k = rc.getAerodrom(icao);
    rc.close();
    return k;
  }

  /**
   * Metoda za dohvat podataka o najduljem putu
   * 
   * @param icao ICAO oznaka odabranog aerodroma
   * @return vraća varijablu tipa UdaljenostAerodromDrzava s podacima
   */
  public UdaljenostAerodromDrzava getPut(String icao) {
    RestKKlijent rc = new RestKKlijent();
    UdaljenostAerodromDrzava k = rc.getPut(icao);
    rc.close();
    return k;
  }

  /**
   * Metoda za dohvat podataka o udaljenosti između dva aerodroma
   * 
   * @param icaoOd ICAO oznaka prvog aerodroma
   * @param icaoDo ICAO oznaka drugog aerodroma
   * @return vraća listu udaljenosti za tražene aerodrome
   */
  public List<Udaljenost> getAerodromiUdaljenost(String icaoOd, String icaoDo) {
    RestKKlijent rc = new RestKKlijent();
    List<Udaljenost> u = rc.getAerodromiUdaljenost(icaoOd, icaoDo);
    rc.close();
    return u;
  }

  /**
   * Metoda za dohvat podataka o udaljenosti između odabranog aerodroma i svih drugih
   * 
   * @param icao ICAO oznaka odabranog aerodroma
   * @param broj količina zapisa koju želimo dohvatiti iz baze podataka
   * @param odBroja oznaka reda od kojeg želimo dohvatiti zapise iz baze podataka
   * @return vraća varijablu tipa UdaljenostAerodrom s podacima
   */
  public List<UdaljenostAerodromDrzava> getUdaljenosti(String icao, int odBroja, int broj) {
    RestKKlijent rc = new RestKKlijent();
    List<UdaljenostAerodromDrzava> udaljenosti = new ArrayList<UdaljenostAerodromDrzava>();
    udaljenosti = rc.getUdaljenosti(icao, odBroja, broj);
    rc.close();
    return udaljenosti;
  }

  /**
   * Klasa REST servisa za slanje zahtjeva u prvu aplikaciju
   */
  static class RestKKlijent {

    private final WebTarget webTarget;
    private final Client client;
    private static final String BASE_URI = konfig.dajPostavku("adresa.wa_1");
    // private static final String BASE_URI = "http://localhost:8080/dkusic_zadaca_2_wa_1/api";

    /**
     * Konstruktor REST servisa, postavlja osnovnu putanju
     */
    public RestKKlijent() {
      client = ClientBuilder.newClient();
      webTarget = client.target(BASE_URI).path("aerodromi");
    }

    /**
     * Metoda za dohvat podataka o svim aerodromima
     * 
     * @param broj količina zapisa koju želimo dohvatiti iz baze podataka
     * @param odBroja oznaka reda od kojeg želimo dohvatiti zapise iz baze podataka
     * @return vraća listu Aerodroma
     */
    public List<Aerodrom> getAerodromi(int odBroja, int broj) throws ClientErrorException {
      WebTarget resource = webTarget;
      resource = resource.queryParam("odBroja", odBroja).queryParam("broj", broj);
      Invocation.Builder request = resource.request(MediaType.APPLICATION_JSON);
      if (request.get(String.class).isEmpty()) {
        return null;
      }
      Gson gson = new Gson();
      var listaAerodroma = new TypeToken<List<Aerodrom>>() {}.getType();
      List<Aerodrom> aerodromi = gson.fromJson(request.get(String.class), listaAerodroma);
      return aerodromi;
    }

    /**
     * Metoda za dohvat podataka o odabranom aerodromu
     * 
     * @param icao ICAO oznaka odabranog aerodroma
     * @return vraća varijablu klase Aerodrom s podacima
     */
    public Aerodrom getAerodrom(String icao) throws ClientErrorException {
      WebTarget resource = webTarget;
      resource = resource.path(java.text.MessageFormat.format("{0}", new Object[] {icao}));
      Invocation.Builder request = resource.request(MediaType.APPLICATION_JSON);
      if (request.get(String.class).isEmpty()) {
        return null;
      }
      Gson gson = new Gson();
      Aerodrom aerodrom = gson.fromJson(request.get(String.class), Aerodrom.class);
      return aerodrom;
    }

    /**
     * Metoda za dohvat podataka o najduljem putu
     * 
     * @param icao ICAO oznaka odabranog aerodroma
     * @return vraća varijablu tipa UdaljenostAerodromDrzava s podacima
     */
    public UdaljenostAerodromDrzava getPut(String icao) throws ClientErrorException {
      WebTarget resource = webTarget;
      resource = resource
          .path(java.text.MessageFormat.format("{0}/najduljiPutDrzave", new Object[] {icao}));
      Invocation.Builder request = resource.request(MediaType.APPLICATION_JSON);
      if (request.get(String.class).isEmpty()) {
        return null;
      }
      Gson gson = new Gson();
      UdaljenostAerodromDrzava udaljenosti =
          gson.fromJson(request.get(String.class), UdaljenostAerodromDrzava.class);
      return udaljenosti;
    }

    /**
     * Metoda za dohvat podataka o udaljenosti između dva aerodroma
     * 
     * @param icaoOd ICAO oznaka prvog aerodroma
     * @param icaoDo ICAO oznaka drugog aerodroma
     * @return vraća listu udaljenosti za tražene aerodrome
     */
    public List<Udaljenost> getAerodromiUdaljenost(String icaoOd, String icaoDo)
        throws ClientErrorException {
      WebTarget resource = webTarget;
      resource =
          resource.path(java.text.MessageFormat.format("{0}/{1}", new Object[] {icaoOd, icaoDo}));
      Invocation.Builder request = resource.request(MediaType.APPLICATION_JSON);
      if (request.get(String.class).isEmpty()) {
        return null;
      }
      Gson gson = new Gson();
      var listaUdaljenosti = new TypeToken<List<Udaljenost>>() {}.getType();
      List<Udaljenost> udaljenost = gson.fromJson(request.get(String.class), listaUdaljenosti);
      return udaljenost;
    }

    /**
     * Metoda za dohvat podataka o udaljenosti između odabranog aerodroma i svih drugih
     * 
     * @param icao ICAO oznaka odabranog aerodroma
     * @return vraća varijablu tipa UdaljenostAerodrom s podacima
     */
    public List<UdaljenostAerodromDrzava> getUdaljenosti(String icao, int odBroja, int broj)
        throws ClientErrorException {
      WebTarget resource = webTarget;
      resource =
          resource.path(java.text.MessageFormat.format("{0}/udaljenosti", new Object[] {icao}))
              .queryParam("odBroja", odBroja).queryParam("broj", broj);
      Invocation.Builder request = resource.request(MediaType.APPLICATION_JSON);
      if (request.get(String.class).isEmpty()) {
        return null;
      }
      Gson gson = new Gson();
      var listaUdaljenosti = new TypeToken<List<UdaljenostAerodromDrzava>>() {}.getType();
      List<UdaljenostAerodromDrzava> udaljenost =
          gson.fromJson(request.get(String.class), listaUdaljenosti);
      return udaljenost;
    }

    /**
     * Metoda za zatvaranje REST klijenta
     */
    public void close() {
      client.close();
    }
  }
}
