package org.foi.nwtis.dkusic.zadaca_2.mvc;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;


/**
 * Klasa za definiranje putanje REST servisa
 * 
 */
@ApplicationPath("mvc")
public class MvcAplikacija extends Application {

}
