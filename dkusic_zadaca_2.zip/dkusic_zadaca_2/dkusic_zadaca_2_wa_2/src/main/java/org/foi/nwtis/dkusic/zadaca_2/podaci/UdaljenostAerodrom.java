package org.foi.nwtis.dkusic.zadaca_2.podaci;

/**
 * Record za rad sa udaljenostima između aerodroma, uključuje oznaku odredišnog aerodroma
 * 
 * @param icao oznaka aerodroma do kojeg se izražava udaljenost
 * @param km udaljenost kroz državu izražena u kilometrima
 * 
 */
public record UdaljenostAerodrom(String icao, float km) {
}
