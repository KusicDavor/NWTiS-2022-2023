package org.foi.nwtis.dkusic.zadaca_2.podaci;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Klasa Aerodrom, za rad s podacima o aerodromima
 * 
 * @author Dragutin Kermek
 * @version 2.3.0
 */
@AllArgsConstructor()
public class Aerodrom {

  @Getter
  @Setter
  private String icao;
  @Getter
  @Setter
  private String naziv;
  @Getter
  @Setter
  private String drzava;
  @Getter
  @Setter
  private Lokacija lokacija;

  /**
   * Konstruktor klase Aerodrom
   * 
   */
  public Aerodrom() {}
}
