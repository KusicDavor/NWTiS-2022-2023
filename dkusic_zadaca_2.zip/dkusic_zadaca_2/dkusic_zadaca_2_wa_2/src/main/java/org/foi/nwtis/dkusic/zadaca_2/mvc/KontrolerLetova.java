/*
 * To change this license header, choose License Headers in Project Properties. To change this
 * template file, choose Tools | Templates and open the template in the editor.
 */
package org.foi.nwtis.dkusic.zadaca_2.mvc;

import org.foi.nwtis.PostavkeBazaPodataka;
import org.foi.nwtis.dkusic.zadaca_2.podaci.Slusac;
import org.foi.nwtis.dkusic.zadaca_2.rest.RestKlijentLetova;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.json.bind.annotation.JsonbDateFormat;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.View;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Response;

/**
 * Klasa tipa kontroler za upravljanje zahtjevima o letovima
 * 
 * @author Davor Kušić
 */
@Controller
@Path("letovi")
@RequestScoped
public class KontrolerLetova {
  /**
   * Sprema konfiguraciju u varijablu klase PostavkeBazaPodataka
   */
  public static PostavkeBazaPodataka konfig = Slusac.getkonfDB();

  @Inject
  private Models model;

  /**
   * Metoda za proslijeđivanje zahtjeva Rest servisu za dohvat podataka o svim letovima odabranog
   * aerodroma na odabrani dan, koristi GET metodu
   * 
   * @param icao ICAO oznaka aerodroma
   * @param dan dan za koji želimo dohvatiti letove aerodroma
   * @param broj količina zapisa koju želimo dohvatiti iz baze podataka
   * @param odBroja oznaka reda od kojeg želimo dohvatiti zapise iz baze podataka
   */
  @GET
  @Path("{icao}")
  @View("polazakAero.jsp")
  public void getAerodrom(@PathParam("icao") String icao,
      @QueryParam("dan") @JsonbDateFormat("dd.MM.yyyy.") @NotNull String dan,
      @QueryParam("odBroja") @DefaultValue("1") int odBroja,
      @QueryParam("broj") @DefaultValue("20") int broj) {
    try {
      RestKlijentLetova rca = new RestKlijentLetova();
      var lista = rca.getLetoviDan(icao, dan, broj, odBroja);
      model.put("lista", lista);
      model.put("konfig", konfig);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Metoda za proslijeđivanje zahtjeva Rest servisu za dohvat podataka o svim letovima između dva
   * aerodroma na odabrani dan, koristi GET metodu
   * 
   * @param icaoOd ICAO oznaka prvog aerodroma
   * @param icaoDo ICAO oznaka drugog aerodroma
   * @param dan dan za koji želimo dohvatiti letove aerodroma
   */
  @GET
  @Path("{icaoOd}/{icaoDo}")
  @View("polazakAero.jsp")
  public void getLetoviAero(@PathParam("icaoOd") String icaoOd, @PathParam("icaoDo") String icaoDo,
      @QueryParam("dan") @JsonbDateFormat("dd.MM.yyyy.") @NotNull String dan) {
    try {
      RestKlijentLetova rca = new RestKlijentLetova();
      var lista = rca.getLetoviAerodromi(icaoOd, icaoDo, dan);
      model.put("lista", lista);
      model.put("konfig", konfig);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Metoda za proslijeđivanje zahtjeva Rest servisu za spremanje odabranog leta u bazu podataka,
   * koristi POST metodu
   * 
   * @param enkodiraniJson HTML kodirani json odabranog leta
   */
  @POST
  @View("obavijest.jsp")
  public void post(String enkodiraniJson) {
    RestKlijentLetova rca = new RestKlijentLetova();
    Response rez = rca.postaj(enkodiraniJson);
    model.put("response", rez);
    model.put("konfig", konfig);
  }

  /**
   * Metoda za proslijeđivanje zahtjeva Rest servisu za dohvat svih letova spremljenih u bazi
   * podataka, koristi GET metodu
   * 
   */
  @GET
  @Path("spremljeni")
  @View("spremljeni.jsp")
  public void getSpremljeni() {
    try {
      RestKlijentLetova rca = new RestKlijentLetova();
      var mapa = rca.getSpremljeni();
      model.put("mapa", mapa);
      model.put("konfig", konfig);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Metoda za proslijeđivanje zahtjeva Rest servisu za brisanje odabranog leta iz baze podataka,
   * koristi POST metodu
   * 
   * @param id ID oznaka leta (reda) u bazi podataka
   * @param delete opisuje poziv kao brisanje kako bi postojala distinkcija između metode koja zove
   *        letove aerodroma
   */
  @POST
  @Path("{id}")
  @View("obavijest.jsp")
  public void obrisi(@FormParam("id") Integer id, @FormParam("delete") String delete) {
    RestKlijentLetova rca = new RestKlijentLetova();
    Response rez = rca.obrisi(id);
    model.put("response", rez);
    model.put("konfig", konfig);
  }
}
