#!/bin/bash

docker build -t nwtishsqldb_1:1.0.0 . &

wait
