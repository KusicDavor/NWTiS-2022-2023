#!/bin/bash

docker build -t nwtis_bp:1.0.0 . &

wait
