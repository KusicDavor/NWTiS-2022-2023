package org.foi.nwtis.dkusic.podaci;

public record Udaljenost(String drzava, float km) {
}
