package org.foi.nwtis.dkusic.podaci;

public class OdgovorPosluzitelja {
  public int status;
  public String opis;
  public int getStatus() {
    return status;
  }
  public void setStatus(int status) {
    this.status = status;
  }
  public String getOpis() {
    return opis;
  }
  public void setOpis(String opis) {
    this.opis = opis;
  }
}
