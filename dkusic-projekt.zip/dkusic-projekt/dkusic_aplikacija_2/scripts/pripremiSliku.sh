#!/bin/bash

docker build -t dkusic_payara_micro:6.2023.4 . &

wait
