package org.foi.nwtis.dkusic.aplikacija_2.podaci;

public class Zapis {
  public String vrsta;
  public String zahtjev;
  public String getVrsta() {
    return vrsta;
  }
  public void setVrsta(String vrsta) {
    this.vrsta = vrsta;
  }
  public String getZahtjev() {
    return zahtjev;
  }
  public void setZahtjev(String zahtjev) {
    this.zahtjev = zahtjev;
  }
}
