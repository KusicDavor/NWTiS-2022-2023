package org.foi.nwtis.dkusic.aplikacija_5.mvc;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("mvc")
public class MvcAplikacija extends Application {
}