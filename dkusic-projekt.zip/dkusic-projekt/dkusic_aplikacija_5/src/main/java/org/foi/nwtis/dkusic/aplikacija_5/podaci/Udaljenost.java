package org.foi.nwtis.dkusic.aplikacija_5.podaci;

public record Udaljenost(String drzava, float km) {
}
